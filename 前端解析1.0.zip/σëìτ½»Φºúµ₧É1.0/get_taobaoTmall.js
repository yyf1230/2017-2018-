var fs = require("fs");
var $ = require("jquery");

console.log("正在进入淘宝搜索列表");

var llq = ["Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:33.0) Gecko/20100101 Firefox/33.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/601.4.4 (KHTML, like Gecko) Version/9.0.3 Safari/601.4.4","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36 QQBrowser/4.1.4132.400"];
var casper = require("casper").create({
	stepTimeout: 60000,
	pageSettings: {
		loadImages:  true,
        javascriptEnabled: true,
        loadPlugins: true,
        userAgent: llq[parseInt(Math.random() * 4)]
	}
});

var defst = casper.cli;
var listUrl = defst.get("surl"), 
	listUrl = "https://detail.tmall.com/item.htm?spm=a230r.1.14.124.SmH2Da&id=537765543854&ns=1&abbucket=8&skuId=3437214710243",
	items = [], 
	itemIx = {};

console.log("正在连接 "+ listUrl);

casper.start(listUrl, function() {

	casper.then(function(){
		
		_plat = $(this.getPageContent()).find(".icon-service-tianmao").length == 0 ? "淘宝" : "天猫";
	   	casper.waitForSelectorTextChange("#J_SellCounter", function(){
			proItem();
		},function(){
			proItem();
		},1200);

	});
});

function proItem(index){

	// _url = $(this).find(".pic-box-inner .pic a").attr("href");
	// _url = _url.split("//")[0] === "" ? "https:" + _url : _url;
	// _shopName = $(this).find(".shop a span:last-child").text();
	// _payNum = $(this).find(".g-clearfix .deal-cnt").text().split("人")[0];
	// _location = $(this).find(".ctx-box .location").text();
	// _plat = $(this).find(".icon-service-tianmao").length == 0 ? "淘宝" : "天猫";

	casper.then(function(){

		var _host = this.getCurrentUrl().split("/")[2];
		console.log(this.getCurrentUrl().split("/")[2]);
		if(isLimited(_host) === false ){
			// console.log(_items.plat);

			console.log($(this.getPageContent()).find("h3.tb-main-title,div.tb-detail-hd h1").text().trim());
			itemIx.title = $(this.getPageContent()).find("h3.tb-main-title,div.tb-detail-hd h1").text().trim();
			itemIx.shopName = $(this.getPageContent()).find(".slogo-shopname,.shop-name-link,.tb-shop-name strong a").text().trim();
			itemIx.sellerName = $(this.getPageContent()).find(".tb-seller-name,.shopLink").text().trim();
			itemIx.location = $(this.getPageContent()).find("#J_deliveryAdd,#J-From").text();
			itemIx.sale = $(this.getPageContent()).find("#J_SellCounter,.tm-ind-panel li:nth-child(1) .tm-count").text();
			itemIx.comm = $(this.getPageContent()).find("#J_RateCounter,.tm-ind-panel li:nth-child(2) .tm-count").text();
			// items.price = $(this.getPageContent()).find("#J_PromoPriceNum,.tm-promo-price .tm-price").text();

			if($(this.getPageContent()).find("ul.J_TSaleProp").length > 0){
				var _attrs = [];
				$(this.getPageContent()).find(".tb-skin .tb-prop").each(function(){
					_attrs.push($(this).index()+1);
				});
				autoClick($(this.getPageContent()).find("ul.J_TSaleProp"), 0, $(this.getPageContent()).find("ul.J_TSaleProp").length, _attrs, index);	
			}
			
			// console.log("获取第 "+ pageNum +" 页 第 "+ (index+1) +" 个商品信息... 编号: "+ _items.id);

		}else{}
	});

	casper.then(function(){
		console.log(JSON.stringify(itemIx));
	});
}

function autoClick(attrArr, index, len, ix, m_index){
	console.log(" 分类 "+(index+1)+" 总数为: "+attrArr.eq(index).find("li").length);

	attrArr.eq(index).find("li").each(function(i){
		var attrItem = {};
		if((index+1) < len){
			casper.then(function(){
				if($(this.getPageContent()).find("ul.J_TSaleProp").eq(index).find("li").eq(i).attr("class") !== "tb-out-of-stock"){
					if($(this.getPageContent()).find("ul.J_TSaleProp").eq(index).find("li").eq(i).attr("class") === undefined || $(this.getPageContent()).find("ul.J_TSaleProp").eq(index).find("li").eq(i).attr("class").indexOf("tb-selected") == -1){
						casper.thenClick(".tb-skin dl.tb-prop:nth-child(" + ix[index] + ") ul.J_TSaleProp li:nth-child("+ (i+1) +") a");
					}
					attrItem.attr = "【" + $(this.getPageContent()).find("ul.J_TSaleProp").eq(index).find("li").eq(i).find("a").children("span").text() + "】";
					attrItem.price = $(this.getPageContent()).find("#J_PromoPriceNum,.tm-promo-price .tm-price").text();
					autoClick(attrArr, (index+1), len, ix, m_index);
				}
			});
		}else{
			var stockSt = false; 
			casper.then(function() {
				if($(this.getPageContent()).find("ul.J_TSaleProp").eq(index).find("li").eq(i).attr("class") !== "tb-out-of-stock"){					
					stockSt = true;
				}
			});
			casper.then(function(){
				if( stockSt == true){
					if($(this.getPageContent()).find("ul.J_TSaleProp").eq(index).find("li").eq(i).attr("class") === undefined || $(this.getPageContent()).find("ul.J_TSaleProp").eq(index).find("li").eq(i).attr("class").indexOf("tb-selected") == -1){
						casper.thenClick(".tb-skin dl.tb-prop:nth-child(" + ix[index] + ") ul.J_TSaleProp li:nth-child("+ (i+1) +") a");
					}
				}
			});
			
			casper.then(function() {
				if( stockSt == true){
					attrItem.attr = "【" + $(this.getPageContent()).find("ul.J_TSaleProp").eq(index).find("li").eq(i).find("a").children("span").text() + "】";
					if($(this.getPageContent()).find(".tm-promo-price .J_loginCheckProm").length > 0 && $(this.getPageContent()).find(".tm-promo-price .J_loginCheckProm").text() === "登录"){
						attrItem.price = "登陆后确认是否享有此优惠";
					}else{
						attrItem.price = $(this.getPageContent()).find("#J_PromoPriceNum,.tm-promo-price .tm-price").text();
					}
					stockSt = false;
				}
			});
		}
		items.push(attrItem);
		attrItem = {};

	});	
	itemIx.attrNames = items;
};

// function arrPush(arr){
// 	dataItem.push(arr.id);
// 	dataItem.push(arr.plat);
// 	dataItem.push(arr.shopName);
// 	dataItem.push(arr.location);
// 	arr.title = arr.title.replace(/\r/g,"");
// 	arr.title = arr.title.replace(/\n/g,"");
// 	arr.title = arr.title.replace("            ","");
// 	dataItem.push(arr.title);
// 	dataItem.push(arr.attr);
// 	dataItem.push(arr.price);
// 	dataItem.push(arr.payNum);
// 	dataItem.push(arr.url);
// 	xlsx_data.push(dataItem);
// 	dataItem = [];
// }

function isLimited(pra){
	if(pra !== "login.taobao.com" && pra !== "login.tmall.com"){
		return false;
	}else{
		return true;
	}
	return true;
}

function outWeb(codeNum){
	this.clear();
	console.log("子进程退出，退出代码：" + codeNum);
	this.exit(codeNum);
}

casper.run();






