var fs = require('fs'), ms;
var $ = require('jquery');

ms = Date.now();

console.log("正在进入京东产品列表...");
var casper = require('casper').create({
    stepTimeout: 60000,
    waitTimeout: 60000,
    verbose: true,
    pageSettings: {
        loadImages:  false,
        javascriptEnabled: true,
        loadPlugins: false,      
        userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/601.4.4 (KHTML, like Gecko) Version/9.0.3 Safari/601.4.4", 
    }
});

var defst = casper.cli;
var _shopUrl = defst.get("shopUrl"), _sname = defst.get("sname");


casper.start(_shopUrl, function() { 
   	casper.thenClick(".form input.button01");

   	casper.then(function(){
   		ajax_updUrl(this.getCurrentUrl(), _sname);
   	});
});


function ajax_updUrl(url, name){
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/updUrl", 
        data : {
            shopUrl : url,
            sName: name
        },
        success : function(result){
            console.log("success!");
        }
    });
}


casper.run();