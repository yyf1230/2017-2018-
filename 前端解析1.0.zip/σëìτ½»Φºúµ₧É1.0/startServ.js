var http = require("http");
var querystring = require("querystring");
var exec = require('child_process').exec;

var _dts = {
	host: '183.134.100.139',
	port: "8088",
	url: "/idaplus-taskManager/taskmanager/getTask/shopTask.do"
}
_dts["data"] = {
	taskType:4
};
var str_data = querystring.stringify(_dts["data"]);

var _sendts = {
  host: '183.134.100.139',
  port: "8087",
  url: "/idaplus-centrePlatform-web/customer/shopinfomonitor/saveAttrShopData.do"
}


var shopData = [],taskIDs = [];
var tm_shopInfo = "get_tmallShopInfo.js",
	tb_shopInfo = "get_taobaoShopInfo.js",
	tb_shopes = "get_taobaoTmall_shopDataes.js";

var jd_shop = "getShopData_jd.js", 
	jd_shopUrl = "get_jd_ShopUrl.js",
	jd_shopInfo = "get_jdShopInfo.js";

var taskName = [];
var taskShopItem = [];
var taskList = {};
var taskIDs = [];
var taskID = 0;
var logs = {};
var csvNames = {
  //"taobao_shop":["编号","标题","价格","销量","评价数量","链接地址"],
  // "taobao_shop":["商品编号","logo地址","平台类型","品牌名称","付款人数","宝贝名称","宝贝成交价格","月销售量","总销售量","评价数量","好评人数","链接地址"],
   "taobao_shop":["goodId","logoUrl","platformId","brandName","payVolume","goodsName","goodsPrice","monthSalesVolume","allAssessVolume","assessVolume","favoriteCount","detailUrl"],
  // "taobao_shop_month": ["编号","标题","价格","销量","链接地址"],
}

var getTaskTimer = iTimer();





var _tData_1 = {
  "taskName" : "特步官方旗舰店", 
  "taskInfo": [{
    "shopName": "特步官方旗舰店",
    "shopUrl": 'https://xtep.tmall.com/shop/view_shop.htm?spm=a230r.1.14.44.mDGyW1&user_number_id=353571709',
  }],
}
var _tData = {
  "taskName" : "测试天猫111111", 
  "taskInfo": [{
    "shopName": "原创少女泳衣日韩BIKI",
    "shopUrl": 'https://shop278025896.taobao.com/search.htm?spm=a1z10.1-c.w5002-15469683867.1.fSh9so&search=y',
  }],
}
// AddTaskBasis(_tData_1);


http.createServer(function (request, response){
   request.setEncoding('utf-8');
  
    var postData = "";
    request.addListener("data", function (postDataChunk){
        postData += postDataChunk;
    });


   request.addListener("end", function() {
      console.log('数据接收完毕');
      var params = querystring.parse(postData);
      switch(request.url){
        case  "/setPar": 
          setVal_jd(params["sName"],params["newNum"]);
          break;
        case "/updUrl":
          SetUrl(params["shopUrl"],params["sName"]);
          break;
        case "/setShopInfo":
          setSpInfo(params["val"],params["sname"]);
          break;
        case "/csv": 
          expExcel(params["val"],params["sname"],params["stype"]);
          break;
        case "/countSales":
          countSales(params["val"],params["sname"]);
          break;
      }
          response.end("数据接收完毕");
    });
}).listen(9010);
console.log("启动本地数据通道: 9010");




function getTask(pdata){
	var body = "";
	var options = {
	    host: pdata["host"],
	    path: pdata["url"],
	    port: pdata["port"],
	    method: 'POST',
	    headers: {
	        'Content-Type': 'application/x-www-form-urlencoded',
        	'Content-Length': Buffer.byteLength(str_data)
	    }
	};

	var req = http.request(options, function(res){
	    res.on('data',function(d){
	        body += d;
	    }).on('end', function(){
	        if(body !== ""){
	        	analyTask(body);
	        }

	    });
	}).on('error', function(e) {
	    console.log("请求错误: " + e.message);
	});

	req.write(str_data);
	req.end();
}

function sendTaskData(taskData,shopInfo){
  var body = "";
  var data = {
    "shopData": JSON.stringify(shopInfo)
  };
  var _info = querystring.stringify(data);
  console.log(_info);
  var options = {
      host: taskData["host"],
      path: taskData["url"],
      port: taskData["port"],
      method: 'POST',
      headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(_info)
      }
  };


  var req = http.request(options, function(res){
      res.on('data',function(d){
          body += d;
      }).on('end', function(){
          if(body !== ""){
            
           var res = querystring.parse(body);
           if(res["result"] === "false"){
              console.log(body);
              console.log("服务器接收数据失败！");
           }else{
              console.log(body);
              console.log("服务器接收数据成功！");
           }

          }else{
            consoel.log("未获取到返回数据！");
          }

      });
  }).on('error', function(e) {
      console.log("请求错误: " + e.message);
  });

  req.write(_info);
  req.end();
}



// getTask(_dts);


function analyTask(taskData){
	var _data = JSON.parse(taskData);
	 console.log(_data);
	console.log(_data.objectId + "=====");
    shopData.push({
      "taskName" : _data.taskId,
      "taskInfo": [{
        "shopName": _data.taskId,
        "shopUrl": _data.taskUrl,
      }],
      "id": _data.taskId,
      "object_Id": _data.objectId === undefined ? 0 : _data.objectId,
      "create_taskId": _data["taskId"] = undefined ? 0 : _data["taskId"]
    });
    if(shopData.length <= 1){
     
      if(_data.taskType == 10){
        AddTaskBasis(shopData[0]);
      }
      clearInterval(getTaskTimer);
      console.log("接收到新任务，当前任务池等待任务数：" + shopData.length);
    }
  
}




// function AddTask(data) {
//     if(taskIDs.length == 2){
//       console.log("任务已满，拒绝任务");
//     }else{
//       if(dirNames.indexOf(data["taskName"]) == -1){
//         taskName.push(data.taskName);
        
//         if(taskIDs.indexOf(1) == -1){
//           taskID = 1;
//         }else{
//           taskID = 2;
//         }
//         taskIDs.push(taskID);
//         console.log("接收到新任务: " + data.taskName);


//         var _taskItem = taskList[data.taskName] = {};
//         _taskItem["taskInfo"] = data.taskInfo;
//         _taskItem["defUrlIndex"] = 0;
//         _taskItem["rootUrl"] = '"' + _taskItem.taskInfo[_taskItem.defUrlIndex].shopUrl +'"';
//         _taskItem["rootNum"] = 1;
//         _taskItem["rootProCount"] = 1;
//         _taskItem["taskID"] = taskID;
//         _taskItem["_2taobao"] = 0; 
//         _taskItem["object_Id"] = data["object_Id"];

//         console.log("开始任务！");
//         console.log("当前任务数:" + taskIDs.length);
//         console.log("任务池任务数：" + shopData.length);
//         shopData.splice(0,1);
//         console.log("任务池释放一条运行任务，剩余数：" + shopData.length);

//         if(_taskItem["rootUrl"].split("/")[2].split(".").indexOf("taobao") != -1){
//           console.log("正站在连接淘宝...");
//           _taskItem["shopFile"] = tb_shop;

//           iCommand(tb_shopInfo, _taskItem["rootUrl"], data.taskName, function(){
//             _taskItem["rootUrl"] =  "https://" + _taskItem["rootUrl"].split("/")[2] + "/search.htm?search=y";
//             iexec(data.taskName);
//           });
//         }else if(_taskItem["rootUrl"].split("/")[2].split(".").indexOf("tmall") != -1){
//           console.log("正站在连接天猫...");
//           _taskItem["shopFile"] = tb_shop;
//           iCommand(tm_shopInfo, _taskItem["rootUrl"], data.taskName, function(){
//             _taskItem["rootUrl"] =  "https://" + _taskItem["rootUrl"].split("/")[2] + "/search.htm?search=y";
//             iexec(data.taskName);
//           });
//         }else{
//           console.log("正站在连接京东...");
//           _taskItem["shopFile"] = jd_shop;
//           iCommand(jd_shopUrl, _taskItem["rootUrl"], data.taskName, function(){
//               iCommand(jd_shopInfo, _taskItem["rootUrl"], data.taskName, function(){
//                 iexec(data.taskName);
//               });
//           });
//         }
//       }else{
//       }
//     }
//  }


//获取店铺基础信息
function AddTaskBasis(data){
	    if(taskIDs.length == 1){
	      console.log("任务已满，拒绝任务");
	    }else{

	        taskName.push(data.taskName);
	        
	        taskIDs.push(taskID);
	        console.log("接收到新任务: " + data.taskName);
	
	        _taskItem = shopInfoInit(data.taskName,data);

	        console.log("开始任务！");
	        console.log("当前任务数:" + taskIDs.length);
	        console.log("任务池任务数：" + shopData.length);
	        shopData.splice(0,1);
	        console.log("任务池释放一条运行任务，剩余数：" + shopData.length);

	        var _plat = distPlat(_taskItem["rootUrl"]);


	        switch(_plat){
	        	case "taobao":
	        		console.log("正站在连接淘宝...");
			        _taskItem["shopFile"] = tb_shopes;

			        iCommand(tb_shopInfo, _taskItem["rootUrl"], data.taskName, function(){
			          _taskItem["rootUrl"] =  "https://" + _taskItem["rootUrl"].split("/")[2] + "/search.htm?search=y";
			          iexec(data.taskName);
			        });
	        		break;
	        	case "tmall":
	        		console.log("正站在连接天猫...");
		          	_taskItem["shopFile"] = tb_shopes;
		          	iCommand(tm_shopInfo, _taskItem["rootUrl"], data.taskName, function(){
		          	  _taskItem["rootUrl"] =  "https://" + _taskItem["rootUrl"].split("/")[2] + "/search.htm?search=y";
		          	  iexec(data.taskName);
		          	});
	        		break;
	        	case "jd":
	        		console.log("正站在连接京东...");
		          	_taskItem["shopFile"] = jd_shop;
		          	iCommand(jd_shopUrl, _taskItem["rootUrl"], data.taskName, function(){
		          	    iCommand(jd_shopInfo, _taskItem["rootUrl"], data.taskName, function(){
		          	      iexec(data.taskName);
		          	    });
		          	});
	        		break;
	        }


	    }
}

//平台判断
function distPlat(url){
	var _plat = url.split("/")[2].split(".");
	if(_plat.indexOf("www") > 0){
		return "err";
	}

	if(_plat.indexOf("taobao") > 0 || _plat.indexOf("jiyoujia") > 0){
		return "taobao";
	}else if(_plat.indexOf("tmall") > 0){
		return "tmall";
	}else if(_plat.indexOf("jd") > 0){
		return "jd";
	}else{
		console.log(_plat);
		return "other";
	}
}

function shopInfoInit(name,data){
	var _taskItem = taskList[name] = {};
	_taskItem["taskInfo"] = data.taskInfo;
	_taskItem["defUrlIndex"] = 0;
	_taskItem["rootUrl"] = '"' + _taskItem.taskInfo[_taskItem.defUrlIndex].shopUrl +'"';
	_taskItem["rootNum"] = 1;
	_taskItem["rootProCount"] = 1;
	_taskItem["taskID"] = 0;
	_taskItem["_2taobao"] = 0; 
	_taskItem["create_taskId"] = data["create_taskId"];
  _taskItem["object_Id"] = data["object_Id"];
	return _taskItem;
}



//replace(/"/g,"");



function iCommand(comFile,url, tName, func){
  var _dos  = exec("casperjs "+ comFile + " --shopUrl=" + url + " --sname=" + tName);
  _dos.stdout.on('data', function(data) {
      console.log(data);
  });

  _dos.stderr.on('data', function (data) {
      console.log('报错啦~~：\n' + data);
  });

  _dos.on('exit', function (code, plat, type) {
    if(code !== 0){
        console.log("子进程非正常退出，代码：" + code);
        iCommand(comFile,url,tName, func);
    }else{
      console.log("子进程正常退出，代码：" + code);
      func();
    }
  });
}

function iexec(tName){
  var _taskItem = taskList[tName];
  var _dos  = exec("casperjs "+ _taskItem.shopFile + " --surl="+_taskItem.rootUrl + " --snum="+_taskItem.rootNum + " --scount="+_taskItem.rootProCount + " --sid="+ _taskItem.taskID + " --sww=" + _taskItem["shopInfo"]["wangWang"] + " --sreg=" + _taskItem["shopInfo"]["region"]+ " --sname=" + tName + " --xy="+_taskItem._2taobao);
  _dos.stdout.on('data', function(data) {
      console.log(data);
  });

  _dos.stderr.on('data', function (data) {
      console.log('报错啦~~：\n' + data);
  });

  _dos.on('exit', function (code, plat, type) {
    if(code !== 0){
      if(code === 2){
        console.log("子进程受限退出，代码：" + code + "... 重新拨号 ...");
         iexec(tName);
        
      }else{
        console.log("子进程非正常退出，代码：" + code );
        iexec(tName);
      }
    }else{
      console.log("子进程正常退出，代码：" + code);
      if(_taskItem.defUrlIndex < _taskItem.taskInfo.length - 1){
        shopComm(tName);
      }else{
        console.log("任务"+_taskItem.taskID+": 所有产品检索完毕, 任务完成！");
        if(taskIDs.length > 0){
          // console.log(taskList[tName]["shopInfo"]);
          // sendMessage(JSON.stringify(taskList[tName]["shopInfo"]));

          taskList[tName]["shopInfo"]["shopItems"] = taskShopItem;
          
          // console.log(taskList[tName]["shopInfo"]);

          
          sendTaskData(_sendts,taskList[tName]["shopInfo"]);

          taskName = arrDel(taskName,tName);
          taskIDs = arrDel(taskIDs, _taskItem.taskID);
          taskList = jsonDel(taskList,tName);
          logs = jsonDel(logs, tName);
          taskShopItem = [];

          if(shopData.length > 0){
              AddTaskBasis(shopData[0]);
          }



          if(taskIDs.length > 0){
            console.log("当前任务数:" + taskIDs.length);
          }else{
            console.log("当前任务状态：空闲");
            getTaskTimer = iTimer();
          }
        }
        
      }
    }
  });
}



function setSpInfo(shopInfo, tName){
  taskList[tName]["shopInfo"] = JSON.parse(shopInfo);
  taskList[tName]["shopInfo"]["salesVol"] = 0;
  taskList[tName]["shopInfo"]["state"] = "1";
  taskList[tName]["shopInfo"]["create_taskId"] = taskList[tName]["create_taskId"];
  taskList[tName]["shopInfo"]["object_Id"] = taskList[tName]["object_Id"];
}
function countSales(sales, tName){
  taskList[tName]["shopInfo"]["salesVol"] = sales;
}

function expExcel(data, tName, type){
  var _taskItem = taskList[tName];
  var datares = JSON.parse(data);
  var rootArr = [], childArr = [];

  if(_taskItem["rootNum"] == 1 && type !== undefined){
    rootArr = [csvNames[type]];
  }

  for(dataroot in datares){
    for(datachild in datares[dataroot]){
      childArr.push(datares[dataroot][datachild]);
    }
    rootArr.push(childArr);
    childArr = [];
  }

  var _shopItems = [];
  var _items = {};
  if(rootArr.length > 2){
    rootArr.forEach(function(res,i){
       if(i > 0){
          res.forEach(function(item,m){
            _items[rootArr[0][m]] = item;
          });
          _shopItems.push(_items);
          _items = {};
       }
    });
  }

  taskShopItem = _shopItems;

  // console.log(_shopItems);

  // console.log(rootArr);
  
};

function setVal_jd(tName ,_inum){
  taskList[tName]["rootNum"] = _inum;
}
function SetUrl(sUrl, tName){
  taskList[tName]["rootUrl"] = '"' + sUrl + '"';
} 

function arrDel(arr, str){
  arr.forEach(function(res, i){
    if(res === str){
      arr.splice(i,1);
    }
  });
  return arr;
}

function jsonDel(json, name){
  var _json = {};

  for(jsonName in json){
    if(jsonName !== name){
      _json[jsonName] = json[jsonName];
    }
  }
  return _json;
}



function iTimer(){
  return setInterval(function(){
    console.log("等待任务ing...");
    getTask(_dts);
  }, 10000);
}