var fs = require("fs"), ms = Date.now();
var $ = require("jquery");


var casper = require("casper").create({
	stepTimeout: 60000,
	waitTimeout: 60000,
	verbose: true,
	pageSettings: {
		loadImages: true,
		javascriptEnabled: true,
		diskcache:false,
		loadPlugins: true,
		userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36'
	}
});

casper.echo("正在打开链接!请稍后...","INFO");

var defst = casper.cli;

var pageCount = defst.get("scount"), Pcount, pageNum = defst.get("snum");
var _surl = defst.get("surl");
var _sid = defst.get("sid"), _sname = defst.get("sname");
var _sww = defst.get("sww"), _sreg = replaceRegion(defst.get("sreg"));
var listUrl = _surl, shopType = 0;

 var xlsx_data = [];
var dataItem = ["","","","","","","","","","","",""];
var items = [], itemIx = [];
var platName = "", shopSalesCount = 0;

casper.echo("正在连接 " + listUrl,"INFO");

casper.start(listUrl, function(){
	casper.then(function(){
		if(this.getCurrentUrl().split("/")[2].split(".").indexOf("taobao") != -1){
			platName = "淘宝";
		}else{
			platName = "天猫";
		}
		nextPage();
	});
});

function nextPage(){
	casper.then(function(){
		if(platName === "淘宝"){
			casper.waitForSelectorTextChange('.shop-hesper-bd', function(){
				taobaoShop();
			},function(){
				taobaoShop();
			},5000);
		}else{
			console.log(this.getCurrentUrl());
			casper.waitForSelectorTextChange("#bd",function(){
				tmallShop();
			},function(){
				tmallShop();
			},3000);
		}
	});
};

function taobaoShop(){
		var sepNum = 0;
	casper.then(function(){

		var shopTypeKey = $(this.getPageContent()).find(".shop-hesper-bd ul.shop-list").find("li").length;
		console.log(shopTypeKey);
		if(shopTypeKey === undefined || shopTypeKey === 0){
			$(this.getPageContent()).find(".shop-hesper-bd").children().each(function(i){
				
				if($(this).attr("class") === "pagination"){
					sepNum = i;
				}
				
				casper.then(function(){
					if(i < sepNum && i > 0){
						$(this.getPageContent()).find(".shop-hesper-bd").children().eq(i).find(".item").each(function(){
							dataItem[0] = $(this).attr("data-id");
							//.replace(/\s+/g,"")
							dataItem[1] = "http:" + $(this).find(".photo .J_TGoldData img").attr("src");
							dataItem[2] = "taobao";
							dataItem[5] = $(this).find(".item-name").text().trim();
							dataItem[6] = $(this).find(".cprice-area .c-price").text();
							dataItem[7] = $(this).find(".sale-area .sale-num").text();
							dataItem[8] = $(this).find(".title h4 a span").text();
							dataItem[11] = "http:" + $(this).find(".photo .J_TGoldData").attr("href");
							xlsx_data.push(dataItem);
							dataItem = ["","","","","","","","","","","",""];
							pageCount++;
						});
					}else if(i >= sepNum && i > 0){
							return ;
					}
				});
				
			});
		}else{

			console.log("出错啦~");
			this.exit(1);
			// shopType = 1;
			// var _url = [];
			// 	$(this.getPageContent()).find(".shop-hesper-bd ul.shop-list").find("li").each(function(m){

			// 		dataItem.push(pageCount);

			// 		dataItem.push($(this).find(".desc a").text().trim());
			// 		dataItem.push($(this).find(".price strong").text());
			// 		dataItem.push($(this).find(".sales-amount em").text());
			// 		dataItem.push($(this).find(".desc a").attr("href"));

			// 		xlsx_data.push(dataItem);
			// 		dataItem = ["","","","","","","","","","","",""];
			// 		pageCount++;
			// 	});
		}
	});

	casper.then(function(){
		Pcount = $(this.getPageContent()).find(".shop-hesper-bd .shop-filter .pagination .page-info").text().split("/")[1];
		console.log("任务"+ _sid +": 获取第 " + pageNum + " 页数据... 共 " + Pcount + "页");
		// ajax_log(_sid, pageNum, Pcount, _sname);
		if(pageNum < Pcount){
			pageNum++;
			if(shopType == 1){
				listUrl = _surl + "&pageNo=" + pageNum;
			}else{
				listUrl = _surl + "&pageNum=" + pageNum;
			}
			
			casper.thenOpen(listUrl,function(){
				nextPage();
			});
		}else{
			casper.then(function(){
				var i_json = {}, i_json_item = {};

				xlsx_data.forEach(function(res, i){
					res.forEach(function(resItem, j){
						i_json_item["child"+j] = resItem;
						i_json["root"+i] = i_json_item;
					});
					i_json_item = {};
				});
				if(shopType == 1){
					ajax_csv(i_json, _sname,"taobao_shop_month");
				}else{
					ajax_csv(i_json, _sname,"taobao_shop");
				}
				
			});
			
			casper.wait(3000,function(){
				this.clear();
				console.log("店铺产品抓取完成！ 清理上下文！");
				this.exit(0);
			});
		}
	});
}

function tmallShop(){
	var sepNum = 0, itemLen = 0;
	casper.then(function(){
		itemLen = $(this.getPageContent()).find(".J_TItems").children().length;

		Pcount = $(this.getPageContent()).find("b.ui-page-s-len").text().split("/")[1];
		Pcount = parseInt(Pcount);
		if(Pcount !== Pcount){
			casper.echo("页面出错重新加载","COMMENT");
			this.exit(1);
		}

		$(this.getPageContent()).find(".J_TItems").children().each(function(i){
				
				if($(this).attr("class") === "pagination"){
					sepNum = i;
				}

				// dataItem.push(pageCount);

				casper.then(function(){
					if(i < sepNum){
						var bdItems = $(this.getPageContent()).find(".J_TItems").children().eq(i).find(".item");
						console.log(bdItems.length + " ====== " + i);

						if(i < itemLen && bdItems.length === 0){
							this.exit(1);
						}

						bdItems.each(function(m){
							casper.then(function(){
								// casper.echo("任务："+_sname+"-获取第 " + pageNum + " 页,第 "+ ((i - 1) * 3 + m + 1) +" 个产品,总页数：" + Pcount,"INFO");
								dataItem[0] = bdItems.eq(m).attr("data-id");
								dataItem[1] = "http:" + bdItems.eq(m).find(".photo .J_TGoldData img").attr("data-ks-lazyload");
				   				dataItem[2] = "tmall";
								dataItem[5] = bdItems.eq(m).find(".item-name").text().trim();
								dataItem[6] = bdItems.eq(m).find(".c-price").text().trim();
								dataItem[7] = bdItems.eq(m).find(".sale-num").text();
								dataItem[8] = bdItems.eq(m).find(".rates .title h4 a span").text().replace("评价: ","");
								dataItem[11] = "http:" + bdItems.eq(m).find(".item-name").attr("href");


								// console.log("任务："+_sname+"-图片地址：" + dataItem[1]);
								// console.log("任务："+_sname+"-宝贝名称：" + dataItem[5]);
								// console.log("任务："+_sname+"-宝贝成交价格：" + dataItem[6]);
								// console.log("任务："+_sname+"-总销售量：" + dataItem[8]);
								// console.log("任务："+_sname+"-评价人数：" + dataItem[9]);
								// console.log("任务："+_sname+"-宝贝详情地址：" + dataItem[11]);

								shopSalesCount += parseInt(dataItem[8]);
							});

							// casper.then(function(){
   				// 				casper.thenOpen(dataItem[11],function(){

   				// 					this.scrollTo(0, 800);

   				// 					console.log(this.getCurrentUrl().split("/")[2]);
   				// 					if(this.getCurrentUrl().split("/")[2].split(".")[0] === "login"){
   				// 						this.clear();
   				// 						casper.echo("天猫受限，清除缓存重新连接...","WARNING");
   				// 						this.exit(2);
   				// 					}

   				// 					casper.waitForSelectorTextChange("#J_BrandAttr",function(){
							// 			dataItem[3] = $(this.getPageContent()).find(".J_EbrandLogo").text();
							// 			console.log("任务："+_sname+"-品牌名称：" + dataItem[3]);
   				// 					},function(){
							// 			dataItem[3] = $(this.getPageContent()).find(".J_EbrandLogo").text();
							// 			console.log("任务："+_sname+"-品牌名称：" + dataItem[3]);
   				// 					},3000);

   				// 					casper.waitForSelectorTextChange("#J_RateCounter .tm-count",function(){
   				// 						dataItem[0] = this.getElementAttribute('div#LineZing', 'itemid');
		   		// 						dataItem[7] = $(this.getPageContent()).find(".tm-ind-sellCount .tm-count").text();
		   		// 						dataItem[9] = $(this.getPageContent()).find(".tm-ind-emPointCount .tm-count").text();
		   								
		   		// 						console.log("任务："+_sname+"-商品编号：" + dataItem[0]);
		   		// 						console.log("任务："+_sname+"-月销售量：" + dataItem[7]);
		   		// 						console.log("任务："+_sname+"-评价数量：" + dataItem[9]);
		   		// 						this.clear();
		   								
   				// 					},function(){
   				// 						dataItem[0] = this.getElementAttribute('div#LineZing', 'itemid');
		   		// 						dataItem[7] = $(this.getPageContent()).find(".tm-ind-sellCount .tm-count").text();
		   		// 						dataItem[9] = $(this.getPageContent()).find(".tm-ind-emPointCount .tm-count").text();
		   								
		   		// 						console.log("任务："+_sname+"-商品编号：" + dataItem[0]);
		   		// 						console.log("任务："+_sname+"-月销售量：" + dataItem[7]);
		   		// 						console.log("任务："+_sname+"-评价数量：" + dataItem[9]);
		   		// 						this.clear();
   				// 					},1000);
   				// 				});

   				// 			});

							// casper.then(function(){
							// 	casper.back();
							// })

							// casper.then(function(){
							// 	casper.thenOpen("http://www.taobao.com",function(){
							// 		casper.then(function(){
							// 			this.fill('form#J_TSearchForm', {
							// 			    'q':dataItem[5],
							// 		  	}, true);
							// 		});
							// 	});
   				// 			});

   				// 			casper.wait(1000,function(){
   				// 				casper.thenOpen(this.getCurrentUrl() + "&loc=" + _sreg + "&filter=reserve_price%5B"+dataItem[6]+"%2C%5D", function(){
   				// 					this.scrollToBottom();
   				// 					casper.wait(1000,function(){
   				// 						$(this.getPageContent()).find(".m-itemlist .grid .items:first-child .item").each(function(){
							// 				if($(this).find(".ctx-box .title").text().trim() === dataItem[5] && $(this).find(".ctx-box .shop .shopname").text().trim() === _sww){
							// 					dataItem[4] = $(this).find(".deal-cnt").text().replace("人付款","");
							// 					console.log("任务："+_sname+"-付款人数：" + dataItem[4]);
							// 					casper.back();
							// 					casper.back();
							// 					casper.back();
							// 					return false;
							// 				}
							// 			});
   				// 					});
							// 	});
							// });


							// casper.wait(1500,function(){});

							casper.then(function(){
								xlsx_data.push(dataItem);
								dataItem = ["","","","","","","","","","","",""];
								pageCount++;
								// casper.echo("=================产品分割线================","INFO");
							});

						});
					}else if(i >= sepNum && i > 0){
							return false;
					}
				});

				
		
		});
	});

	casper.wait(500,function(){
		
		console.log("任务"+ _sid +": 获取第 " + pageNum + " 页数据... 共 " + Pcount + "页");
		// ajax_log(_sid, pageNum, Pcount, _sname);
		if(pageNum < Pcount){
			pageNum++;
			listUrl = _surl + "&pageNo=" + pageNum;
			casper.thenOpen(listUrl,function(){
				nextPage();
			});
		}else{
			casper.then(function(){
				ajax_countSales();
			});

			casper.then(function(){
				var i_json = {}, i_json_item = {};
				xlsx_data.forEach(function(res, i){
					res.forEach(function(resItem, j){
						i_json_item["child"+j] = resItem;
						i_json["root"+i] = i_json_item;
					});
					i_json_item = {};
				});

				ajax_csv(i_json, _sname,"taobao_shop");
			});

			
			casper.wait(3000,function(){
				this.clear();
				casper.echo("店铺产品抓取完成！ 清理上下文！","INFO");
				this.exit(0);
			});
		}

	});
}

function ajax_csv(data_json,_name, csvType){
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/csv", 
        data : { 
        	stype: csvType,
         	sname: _name,
            val : JSON.stringify(data_json)
        },
        success : function(result){
            console.log("success!");
        }
    });
}

function ajax_countSales(){
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/countSales", 
        data : { 
         	sname: _sname,
            val : shopSalesCount
        },
        success : function(result){
            console.log("success!");
        }
    });
}

function replaceRegion(region){
	var sjmc = ["河北","河南","云南","辽宁","黑龙江","湖南","安徽","山东","新疆","江苏","浙江","江西","湖北","广西","甘肃","山西","内蒙","陕西","吉林","福建","贵州","广东","青海","西藏","四川","宁夏","海南","台湾","香港","澳门"];

	sjmc.forEach(function(res){
		region = region.replace(res,"");
	});
	console.log(region);

	return region;
}



casper.run();