var fs = require('fs'), ms;
var $ = require('jquery');

ms = Date.now();

var casper = require('casper').create({
    stepTimeout: 60000,
    waitTimeout: 60000,
    verbose: true,
    pageSettings: {
        // loadImages:  true,
        // javascriptEnabled: true,
        // loadPlugins: true,      
        diskcache:false,
        // userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/601.4.4 (KHTML, like Gecko) Version/9.0.3 Safari/601.4.4", 
    }
});
casper.echo("正在打开京东链接！请稍后...","INFO");

var defst = casper.cli;

var pageCount, pageNum = defst.get("snum");
var _sheadurl = defst.get("surl").split("html")[0].substring(0,defst.get("surl").split("html")[0].length - 5), _sfooterurl = "-24.html" + defst.get("surl").split("html")[1] , listUrl = _sheadurl + pageNum + _sfooterurl;
var _sname = defst.get("sname");
var xlsx_data = pageNum > 1 ? [] : [["编号","商品名","店铺名","发货地","价格","评价人数","商品地址"]],
    dataItem = ["","","","","","","","","","","",""];
var items = [], itemIx = [];

casper.echo("正在连接 "+ listUrl,"INFO");
casper.start(listUrl, function() {

    casper.wait(1000,function(){
        casper.then(function(){
            var _jpage = parseFloat($(this.getPageContent()).find(".jTotal em").text()) / 24;
            pageCount = _jpage > parseInt(_jpage) ? parseInt(_jpage) + 1 : parseInt(_jpage); 
            console.log(pageCount + " .......[" + _jpage +  "]" + "[" + parseInt(_jpage) + "]");
            // pageCount = _jpage.children().eq(_jpage.children().length - 2).text();
            // pageCount = parseInt(pageCount);
        });
    });
   
    casper.then(function(){
        console.log("总页数：" + pageCount);
        if(isNaN(pageCount) || typeof pageCount !== "number" ){
            this.clear();
            casper.echo("页数获取异常，可能受限，清理上下文！重新拨号！","WARNING");
            this.exit(2);
        }else{


            //  casper.wait(2000, function(){
            //     console.log("滚动条移动到最底部!");
            // });
            // this.scrollToBottom();
            nextPage();
        }
    });
   

});

function nextPage(ibool){
    var _host, _url, _shopName, _location, _plat, _title, _price;

    casper.then(function(){
        if(ibool === true){
            casper.wait(2000,function(){
                casper.then(function(){
                    ajax_setting(pageNum,_sname);
                });
            });
        }
    });

    // casper.wait(2000,function(){}); 

    casper.then(function(){
        if(ibool === true){
            this.clear();
            casper.echo("清理上下文！重启！","COMMENT");
            this.exit(1);
        }
        var jdProlist;

        if($(this.getPageContent()).find("div.fn-clear[module-name='GoodsPage'] .jItem").length != 0){
            jdProlist = $(this.getPageContent()).find("div.fn-clear[module-name='GoodsPage'] .jItem");
        }else if($(this.getPageContent()).find("div.fn-clear[module-name='SearchList'] .jItem").length != 0){
            jdProlist = $(this.getPageContent()).find("div.fn-clear[module-name='SearchList'] .jItem");
        }else if($(this.getPageContent()).find(".userjSearchList .jItem").length != 0){
            jdProlist = $(this.getPageContent()).find(".userjSearchList .jItem");
        }else if($(this.getPageContent()).find(".userSearchList .jItem").length != 0){
            jdProlist = $(this.getPageContent()).find(".userSearchList .jItem");
        }else{
            jdProlist = $(this.getPageContent()).find(".jSearchList ul .jItem");
        }

        console.log(jdProlist.length);
        var _content, attrName = "";
        jdProlist.each(function(m){
            
            _id = (m+1) + 24 * (pageNum - 1);

            items.push({
                id: $(this).find(".jPic a").attr('href').replace("//","").split("/")[1].replace(".html", ""),
                logoUrl: "http:" + $(this).find(".jPic a img").attr("src"),
                url: "http:"+$(this).find(".jPic a").attr('href'),
                shopName: "",
                brandName: "",
                positive: "",
                location: "",
                price: "",
                title: "",
                evaNum: 0
            });
            casper.thenOpen(items[m].url, function(){
                console.log("\n\n" + this.getCurrentUrl());

                casper.echo("获取第 "+ pageNum  +" 页 第 "+ (m+1) +" 个商品信息... 编号："+ items[m].id,"INFO");
                // casper.wait(2000,function(){
                    _content =  this.getPageContent().split("pageConfig =")[1].split(";")[0];
                    _content =  eval('('+ _content +')');
                    _content =  JSON.stringify(_content.product.colorSize) === "{}" ? "{}" : _content;

              
                  
                if($(this.getPageContent()).find("#name h1").text() !== "" && $(this.getPageContent()).find("#name h1").text() !== undefined){

                    console.log("旧....");

                    items[m].brandName = $(this.getPageContent()).find("#parameter-brand li:first-child").attr("title");

                    casper.thenClick("#detail-tab-comm a",function(){
                        this.scrollTo(0, 1500);
                        casper.wait(1000,function(){
                            items[m].positive = $(this.getPageContent()).find("#comments-list .m-tab-trigger li:nth-child(3)").attr("data-num");
                            items[m].evaNum = $(this.getPageContent()).find("#comments-list .m-tab-trigger li:nth-child(1)").attr("data-num");
                        });
                    });

                    casper.then(function(){
                        if($(this.getPageContent()).find(".activity-type strong").text() !== "预售"){
                            if($(this.getPageContent()).find("strong#jd-price").text().trim() === ""){
                                casper.waitForSelectrTextChange("strong#jd-price",function(){
                                    items[m].price = $(this.getPageContent()).find("strong#jd-price").text().replace("￥","");
                                });
                            }else{
                                items[m].price = $(this.getPageContent()).find("strong#jd-price").text().replace("￥","");
                            }

                            if($(this.getPageContent()).find(".seller-infor em.u-jd").text() === undefined || $(this.getPageContent()).find(".seller-infor em.u-jd").text() === ""){
                                if($(this.getPageContent()).find("#summary-service div.dd").text().trim() === ""){
                                     casper.waitForSelectorTextChange("#summary-service",function(){
                                        if($(this.getPageContent()).find("#summary-service div.dd").text().trim() === ""){
                                            
                                            casper.then(function(){
                                                pageErrReload();
                                            });

                                            casper.then(function(){
                                                items[m].location = $(this.getPageContent()).find("#summary-service .dd").text().split(" ")[1] === undefined ? "" : $(this.getPageContent()).find("#summary-service .dd").text().split(" ")[1]; 
                                                console.log($(this.getPageContent()).find("#summary-service .dd").text() + " ..yy");
                                            },function(){
                                                console.log("等待超时！");

                                                casper.then(function(){
                                                    pageErrReload();
                                                });

                                                casper.then(function(){
                                                    items[m].price = $(this.getPageContent()).find("strong#jd-price").text().replace("￥","");
                                                });
                                            });
                                        }else{
                                            items[m].location = $(this.getPageContent()).find("#summary-service .dd").text().split(" ")[1] === undefined ? "" : $(this.getPageContent()).find("#summary-service .dd").text().split(" ")[1]; 
                                            console.log($(this.getPageContent()).find("#summary-service .dd").text() + " ..xx1");
                                        }
                                        
                                     });
                                }else{
                                    items[m].location = $(this.getPageContent()).find("#summary-service .dd").text().split(" ")[1] === undefined ? "" : $(this.getPageContent()).find("#summary-service .dd").text().split(" ")[1];
                                     console.log($(this.getPageContent()).find("#summary-service .dd").text() + " ..xx2");
                                }

                            }else{
                                items[m].location = "京东自营";
                            }


                            // casper.waitForSelectorTextChange("#comment-count a",function(){
                            //     items[m].evaNum = $(this.getPageContent()).find("#comment-count a").text();
                            // }, function(){
                            //     items[m].evaNum = $(this.getPageContent()).find("#comment-count a").text();
                            // }, 1000);

                            casper.then(function(){
                                items[m].url = this.getCurrentUrl();
                                items[m].shopName = $(this.getPageContent()).find(".seller-infor a").text();
                                items[m].title = $(this.getPageContent()).find("#name h1").text();
                                console.log("标题: " + items[m].title);
                                arrPush(items[m]);  
                            });


                        }else{
                            casper.echo("正在预售，跳过2！","COMMENT");
                        }
                    });
                }else{
                    console.log("新....");

                    items[m].brandName = $(this.getPageContent()).find("#parameter-brand li:first-child").attr("title");
                    
                    casper.thenClick("#detail ul li[data-anchor='#comment']",function(){
                        this.scrollTo(0, 1500);
                        casper.wait(1000,function(){
                            items[m].positive = $(this.getPageContent()).find(".J-comments-list ul li:nth-child(3)").attr("data-num");
                            items[m].evaNum = $(this.getPageContent()).find(".J-comments-list ul li:nth-child(1)").attr("data-num");
                        });
                    });

                    casper.then(function(){
                        if($(this.getPageContent()).find(".activity-type strong").text() !== "预售"){
                            if($(this.getPageContent()).find(".summary-price .p-price .price").text().trim() === ""){
                                casper.waitForSelectorTextChange(".summary-price .p-price .price",function(){
                                    items[m].price = $(this.getPageContent()).find(".summary-price .p-price .price").text();
                                });
                            }else{
                                items[m].price = $(this.getPageContent()).find(".summary-price .p-price .price").text();
                            }

                            if($(this.getPageContent()).find("#summary-service").text().trim() === ""){
                                 casper.waitForSelectorTextChange("#summary-service",function(){
                                    if($(this.getPageContent()).find("#summary-service").text().trim() === ""){
                                        
                                        casper.then(function(){
                                            pageErrReload();
                                        });

                                        casper.then(function(){
                                            items[m].location = $(this.getPageContent()).find("#summary-service").text().split(" ")[1] === undefined ? "" : $(this.getPageContent()).find("#summary-service").text().split(" ")[1]; 
                                            console.log($(this.getPageContent()).find("#summary-service").text() + " ..yy");
                                        },function(){
                                            console.log("等待超时！");

                                            casper.then(function(){
                                                pageErrReload();
                                            });

                                            casper.then(function(){
                                                items[m].price = $(this.getPageContent()).find(".summary-price .p-price .price").text();
                                            });
                                        });
                                    }else{
                                        items[m].location = $(this.getPageContent()).find("#summary-service").text().split(" ")[1] === undefined ? "" : $(this.getPageContent()).find("#summary-service").text().split(" ")[1]; 
                                        console.log($(this.getPageContent()).find("#summary-service").text() + " ..xx1");
                                    }
                                    
                                 });
                            }else{
                                items[m].location = $(this.getPageContent()).find("#summary-service").text().split(" ")[1] === undefined ? "" : $(this.getPageContent()).find("#summary-service").text().split(" ")[1];
                                 console.log($(this.getPageContent()).find("#summary-service").text() + " ..xx2");
                            }

                            


                            // casper.waitForSelectorTextChange("#comment-count a",function(){
                            //     items[m].evaNum = $(this.getPageContent()).find("#comment-count a").text();
                            // }, function(){
                            //     items[m].evaNum = $(this.getPageContent()).find("#comment-count a").text();
                            // }, 1000);

                            casper.then(function(){
                                items[m].url = this.getCurrentUrl();
                                items[m].shopName = $(this.getPageContent()).find(".contact .item .name a").text();
                                items[m].title = $(this.getPageContent()).find(".sku-name").text();
                                console.log("标题: " + items[m].title);
                                arrPush(items[m]);  
                            });


                        }else{
                            casper.echo("正在预售，跳过2！","COMMENT");
                        }
                    });
                }
            });
        });
    });
    console.log("打开链接成功! 等待获取商品信息...");


    casper.then(function(){
    
            var i_json = {}, i_json_item = {};

            xlsx_data.forEach(function(res, i){
                res.forEach(function(resItem, j){
                    i_json_item["child"+j] = resItem;
                    i_json["root"+i] = i_json_item;
                });
                i_json_item = {};
            });

            casper.then(function(){
               if(pageNum < pageCount){
                    pageNum++;
                    listUrl = _sheadurl + pageNum + _sfooterurl;
                    casper.thenOpen(listUrl, function() {
                        casper.then(function(){

                            // casper.thenClick(".J_Submit");
                            casper.wait(2000,function(){
                                casper.then(function(){
                                    ajax_csv(i_json,_sname);
                                });

                                casper.then(function(){
                                    items = [];
                                    xlsx_data = [];
                                    nextPage(true);
                                });
                                
                               
                            });
                        });
                    });
                }else{
                    casper.then(function(){
                        ajax_csv(i_json,_sname);
                    });
                    casper.then(function(){
                        ms = Date.now();
                        this.clear();
                        casper.echo("本条链接产品检索完成,清理上下文！","INFO");
                        casper.echo("程序结束！耗时: "+ ms +" msec","INFO");
                        this.exit(0);
                    });
                }       
            });
    });
}

function arrPush(arr){
    dataItem[0] = arr.id;
    dataItem[1] = arr.logoUrl;
    dataItem[2] = "jd";
    dataItem[3] = arr.brandName;
    dataItem[5] = arr.title;
    dataItem[6] = arr.price;
    dataItem[9] = arr.evaNum;
    dataItem[10] = arr.positive;
    dataItem[11] = arr.url;

    console.log("商品编号：" + dataItem[0]);
    console.log("图片地址：" + dataItem[1]);
    console.log("品牌名称：" + dataItem[3]);
    console.log("付款人数：" + dataItem[4]);
    console.log("宝贝名称：" + dataItem[5]);
    console.log("宝贝成交价格：" + dataItem[6]);
    console.log("月销售量：" + dataItem[7]);
    console.log("总销售量：" + dataItem[8]);
    console.log("评价人数：" + dataItem[9]);
    console.log("好评人数：" + dataItem[10]);
    console.log("宝贝详情地址：" + dataItem[11]);

    xlsx_data.push(dataItem);
    dataItem = ["","","","","","","","","","","",""];
}

function pageErrReload(){
    console.log("页面加载出错，重新刷新页面!");
    casper.then(function(){
        this.reload(function(){
           casper.waitForSelectorTextChange("#summary-service",function(){
                console.log($(this.getPageContent()).find("#summary-service").text());
                if($(this.getPageContent()).find("#summary-service").text().trim() !== ""){
                    return true;
                }else{
                    pageErrReload();
                }
           });
        });
    });
}

function ajax_csv(data_json,_name){
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/csv", 
        data : { 
            stype: "taobao_shop", 
            val : JSON.stringify(data_json),
            sname: _name
        },
        success : function(result){
            console.log("success!");
        }
    });
}

function ajax_setting(data_num,_name){
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/setPar", 
        data : {
            newNum : data_num,
            sName: _name
        },
        success : function(result){
            console.log("success!");
        }
    });
}


casper.run();