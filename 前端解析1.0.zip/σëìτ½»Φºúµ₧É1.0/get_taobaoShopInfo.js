var fs = require('fs'), ms;
var $ = require('jquery');

ms = Date.now();


var casper = require('casper').create({
    stepTimeout: 60000,
    waitTimeout: 60000,
    verbose: true,
    pageSettings: {
        loadImages:  true,
        javascriptEnabled: true,
        loadPlugins: true,
        userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/601.4.4 (KHTML, like Gecko) Version/9.0.3 Safari/601.4.4", 
    }
});
casper.echo("正在获取淘宝店铺信息111...","INFO");

var defst = casper.cli;
var _shopUrl = defst.get("shopUrl"), _sname = defst.get("sname");
var _tbShopInfo = {
	platformId: "taobao",
	shopUrl: _shopUrl,
	promise: ""
};

casper.start(_shopUrl,function(){

	_tbShopInfo["shopId"] = this.getElementAttribute('div#LineZing', 'shopid');
	_tbShopInfo["shopName"] = $(this.getPageContent()).find(".first-block .shop-name").text();
	_tbShopInfo["wangWang"] = $(this.getPageContent()).find(".seller-name").text().replace("掌柜：","");

	console.log("店铺id：" + _tbShopInfo["shopId"]);
	console.log("店铺名：" + _tbShopInfo["shopName"]);
	console.log("旺旺id：" + _tbShopInfo["wangWang"]);


	casper.thenOpen("http:" + $(this.getPageContent()).find(".shop-rank a").attr("href"),function(){
		var _content = $(this.getPageContent());
		var _itemScrib_rdRate = _content.find(".dsr-info .J_RateInfoTrigger:nth-child(1) .item-scrib"),
			_itemScrib_fwRate = _content.find(".dsr-info .J_RateInfoTrigger:nth-child(2) .item-scrib"),
			_itemScrib_dsRate = _content.find(".dsr-info .J_RateInfoTrigger:nth-child(3) .item-scrib");

		_tbShopInfo["rank"] = _content.find(".sep li:first-child").text().replace("卖家信用：","").trim();
		_tbShopInfo["mainProducts"] = _content.find("#chart-name").text();
		_tbShopInfo["praiseRate"] = _content.find(".box-shadow-combo h4 em").text().replace("好评率：","");
		_tbShopInfo["rdRate"] = _itemScrib_rdRate.find("em.count").text();
		_tbShopInfo["rdHigherRate"] = (_itemScrib_rdRate.find(".percent").hasClass("over") ? "高" : "低") + _itemScrib_rdRate.find(".percent").text();
		_tbShopInfo["fwRate"] = _itemScrib_fwRate.find("em.count").text();
		_tbShopInfo["fwHigherRate"] = (_itemScrib_fwRate.find(".percent").hasClass("over") ? "高" : "低") + _itemScrib_fwRate.find(".percent").text();
		_tbShopInfo["dsRate"] = _itemScrib_dsRate.find("em.count").text();
		_tbShopInfo["dsHigherRate"] = (_itemScrib_dsRate.find(".percent").hasClass("over") ? "高" : "低") + _itemScrib_dsRate.find(".percent").text();


		console.log("店铺等级：" + _tbShopInfo["rank"]);
		console.log("主营：" + _tbShopInfo["mainProducts"]);
		console.log("好评率：" + _tbShopInfo["praiseRate"]);
		console.log("描述相符率：" + _tbShopInfo["rdRate"]);
		console.log("服务态度：" + _tbShopInfo["fwRate"]);
		console.log("物流服务：" + _tbShopInfo["dsRate"]);
		console.log("描述相符与同行业相比：" + _tbShopInfo["rdHigherRate"]);
		console.log("服务态度与同行业相比：" + _tbShopInfo["fwHigherRate"]);
		console.log("物流服务与同行业相比：" + _tbShopInfo["dsHigherRate"]);
		console.log("店铺请求地址："+ _tbShopInfo["shopUrl"]);


	});

	casper.thenOpen("https://" + _tbShopInfo["shopUrl"].split("/")[2] + "/search.htm?search=y",function(){

		var _regFunc = function(){
				casper.waitForSelectorTextChange('#J-From', function() {
					_tbShopInfo["region"] = $(this.getPageContent()).find("#J-From").text();
		
					if(_tbShopInfo["region"] === ""){
	                    console.log("地区未找到重启！");
	                    this.exit(1);
	                }
					console.log("地区：" + _tbShopInfo["region"]);
				},function(){
					_tbShopInfo["region"] = $(this.getPageContent()).find("#J-From").text();
		
					if(_tbShopInfo["region"] === ""){
	                    console.log("地区未找到重启！");
	                    this.exit(1);
	                }
					console.log("地区：" + _tbShopInfo["region"]);
				}, 1000);
			};
		casper.waitForSelectorTextChange(".shop-hesper-bd",function(){
			casper.thenOpen("https:" + $(this.getPageContent()).find(".shop-hesper-bd").children().eq(1).find(".item").eq(0).find(".photo .J_TGoldData").attr("href"),function(){
				console.log(this.getCurrentUrl());
				_regFunc();
			});
		},function(){
			casper.thenOpen("https:" + $(this.getPageContent()).find(".shop-hesper-bd ul.shop-list li").eq(1).find(".desc a").attr("href"),function(){
				console.log(this.getCurrentUrl());
				_regFunc();
			});
		},3000);
	});
	

	casper.thenOpen("http://www.taobao.com",function(){
		casper.then(function(){
			 this.mouseEvent("click","#J_SearchTab ul li[data-searchtype='shop']");
		});
		casper.thenEvaluate(function(){
			document.querySelector('form#J_TSearchForm').setAttribute('action', "//shopsearch.taobao.com/browse/shop_search.htm");
		});
		casper.then(function(){
			this.fill('form#J_TSearchForm', {
			    'q':_tbShopInfo["shopName"] + " " + _tbShopInfo["wangWang"],
		  	}, true);
		});
		casper.then(function(){
			$(this.getPageContent()).find("#list-container li.list-item").each(function(){
				if($(this).find(".list-info h4 a").text().trim() === _tbShopInfo["shopName"] && $(this).find(".shop-info .shop-info-list a[trace='shop']").text().trim() === _tbShopInfo["wangWang"]){
					_tbShopInfo["logoUrl"] = "http:" + $(this).find(".list-img img").attr("src");
					console.log("店铺log：" + _tbShopInfo["logoUrl"]);
					return false;
				}
			});
		});
	});

	casper.then(function(){
		ajax_setShopInfo(_tbShopInfo);
	});
	casper.wait(1000,function(){});

});


function ajax_setShopInfo(data_json){
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/setShopInfo", 
        data : { 
         	sname: _sname,
            val : JSON.stringify(data_json)
        },
        success : function(result){
            console.log("success!");
        }
    });
}


casper.run();