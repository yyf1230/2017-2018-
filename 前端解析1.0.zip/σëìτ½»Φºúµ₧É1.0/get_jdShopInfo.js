var fs = require('fs'), ms;
var $ = require('jquery');

ms = Date.now();

console.log("正在获取京东店铺信息...");
var casper = require('casper').create({
    stepTimeout: 60000,
    waitTimeout: 60000,
    verbose: true,
    pageSettings: {
        loadImages:  false,
        javascriptEnabled: true,
        loadPlugins: false,      
        userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/601.4.4 (KHTML, like Gecko) Version/9.0.3 Safari/601.4.4", 
    }
});

var defst = casper.cli;
var _shopUrl = defst.get("shopUrl"), _sname = defst.get("sname");
var _jdShopInfo = {
	platformId: "jd",
	shopUrl: "",
	promise: "",
    wangWang: "",
    rank: "",
    mainProducts: "",
    praiseRate: "",
    rdRate: "",
    rdHigherRate: "",
    fwRate: "",
    fwHigherRate: "",
    dsRate: "",
    dsHigherRate: "",
    region: "",
    logoUrl: "",
	proFileUrl: "CSV宝贝文件磁盘路径"
};

casper.start(_shopUrl,function(){
    console.log(this.getCurrentUrl());
    _jdShopInfo["shopId"] = this.getCurrentUrl().split("-")[3];
    _jdShopInfo["shopName"] = $(this.getPageContent()).find(".jLogo").text().trim();
    _jdShopInfo["shopUrl"] = "http://mall.jd.com/index-" + _jdShopInfo["shopId"] + ".html";
    console.log("店铺id：" + _jdShopInfo["shopId"]);
    console.log("店铺名：" + _jdShopInfo["shopName"]);


    if($(this.getPageContent()).find("#jRatingTotal_table").length > 0){
        casper.thenClick("#jRatingTotal_table",function(){

            var _content = $(this.getPageContent());
            
            var _items = _content.find(".j-rating-info .j-score:nth-child(2) .item-180");

            _jdShopInfo["rdRate"] = _items.eq(3).find(".f24").text().replace("分","").trim();
            _jdShopInfo["rdHigherRate"] = (_items.eq(3).find(".percent").parent().parent().hasClass("red") ? "高" : "低") + _items.eq(3).find(".percent").text();
            _jdShopInfo["fwRate"] = _items.eq(1).find(".f24").text().replace("分","").trim();
            _jdShopInfo["fwHigherRate"] = (_items.eq(1).find(".percent").parent().parent().hasClass("red") ? "高" : "低") + _items.eq(1).find(".percent").text();
            _jdShopInfo["dsRate"] = _items.eq(2).find(".f24").text().replace("分","").trim();
            _jdShopInfo["dsHigherRate"] = (_items.eq(2).find(".percent").parent().parent().hasClass("red") ? "高" : "低") + _items.eq(2).find(".percent").text();
            _jdShopInfo["region"] = _content.find(".j-shop-info p:nth-child(3) .value").text().trim();
            _jdShopInfo["logoUrl"] = "http:" + _content.find(".j-shop-logo img").attr("src");

            console.log("描述相符率：" + _jdShopInfo["rdRate"]);
            console.log("服务态度：" + _jdShopInfo["fwRate"]);
            console.log("物流服务：" + _jdShopInfo["dsRate"]);
            console.log("描述相符与同行业相比：" + _jdShopInfo["rdHigherRate"]);
            console.log("服务态度与同行业相比：" + _jdShopInfo["fwHigherRate"]);
            console.log("物流服务与同行业相比：" + _jdShopInfo["dsHigherRate"]);
            console.log("地区：" + _jdShopInfo["region"]);
            console.log("店铺log：" + _jdShopInfo["logoUrl"]);
        
        });
    }

    casper.then(function(){
        console.log("店铺请求地址："+ _jdShopInfo["shopUrl"]);
    });

    casper.then(function(){
        ajax_setShopInfo(_jdShopInfo);
    });
    casper.wait(1000,function(){});
        
});

function ajax_setShopInfo(data_json){
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/setShopInfo", 
        data : { 
            sname: _sname,
            val : JSON.stringify(data_json)
        },
        success : function(result){
            console.log("success!");
        }
    });
}


casper.run();