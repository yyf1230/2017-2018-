var http = require("http");
var querystring = require("querystring");
var fs = require("fs");
var exec = require("child-process").exec;

var _dts = {
    host:"183.134.100.27",
    port:"8888",
    url:"/idaplus-taskManager/taskmanager/getTask/shopTask.do"
};
_dts["comment"] = {
    taskType:4,
    taskId:"",
    isSuccess:1
}

var _send = {
    host: '183.134.100.130',
    port: "8888",
    url: "/idaplusweb/admin/review/saveTaskVo.do"
};
var comment_tmShopInfo = "get_commentTmShopInfo.js",
    comment_tmInfo = "get_commentTmInfo.js",
    comment_jdShopInfo = "get_commentJdShopInfo.js",
    comment_jdShopInfo2 = "get_commentJdShopInfo2.js";

var offnet = "sudo networksetup -setnetworkserviceenabled PPPoE off";
var onnet = "sudo networksetup -setnetworkserviceenabled PPPoE on";
var connect = "networksetup -connectpppoeservice PPPoE";

var getTaskTimer = iTimer(true);
http.createServer(function(request,response){
   request.setEncoding("utf-8");
   response.setHeader('Access-Control-Allow-Origin', '*');
   var postData = "";
   request.addListener("data",function(postDataChunk){
    postData += postDataChunk;
   });
   request.addListenter("end",function(){
       var parsms = querystring.parse(postData);
       switch(request.url){
        //   case
       }
   })
})
