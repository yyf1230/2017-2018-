var fs = require("fs"), ms = Date.now();
var $ = require("jquery");

var casper = require("casper").create({
	stepTimeout: 60000,
	waitTimeout: 60000
});

casper.echo("正在打开链接!请稍后...","INFO");

var defst = casper.cli;

var pageCount = defst.get("scount"), Pcount, pageNum = defst.get("snum");
var _surl = defst.get("surl");
var _sid = defst.get("sid"), _sname = defst.get("sname");
var _sdata = defst.get("sdata");


var _sww = defst.get("sww"), _sreg = replaceRegion(defst.get("sreg"));
var listUrl = _surl, shopType = 0;



 var xlsx_data = [];
//  if(_sdata == 1){
//  	console.log(_sdata)
//  }else{
//  	xlsx_data = _sdata; 
//  	console.log("数据缓存成功！")
//  }
var dataItem = ["","","","","","","","","","","",""];
var items = [], itemIx = [];
var platName = "", shopSalesCount = 0;

casper.echo("正在连接s " + listUrl,"INFO");

casper.start(listUrl, function(){
	casper.then(function(){
		if(this.getCurrentUrl().split("/")[2].split(".").indexOf("taobao") != -1){
			platName = "淘宝";
			nextPage();
		}else{
			listUrl = _surl + "&pageNo=" + pageNum;
			casper.thenOpen(listUrl,function(){
				nextPage();
			});
			platName = "天猫";
		}
		
	});
});

function nextPage(bool){
	if(bool){
		console.log("进入下一页.");
		this.clear();
		this.exit(1);
	}

	casper.then(function(){
		if(platName === "淘宝"){
			casper.waitForSelectorTextChange('.shop-hesper-bd', function(){
				taobaoShop(this.getCurrentUrl());
			},function(){
				taobaoShop(this.getCurrentUrl());
			},3000);
		}else{
			console.log(this.getCurrentUrl());
			casper.waitForSelectorTextChange("#bd",function(){
				tmallShop(this.getCurrentUrl());
			},function(){
				tmallShop(this.getCurrentUrl());
			},3000);
		}
	});
};

function taobaoShop(_url){
	var sepNum = 0, itemLen = 0;
	casper.then(function(){

		var shopTypeKey = $(this.getPageContent()).find(".shop-hesper-bd ul.shop-list").find("li").length;
		if(shopTypeKey === undefined || shopTypeKey === 0){
			itemLen = $(this.getPageContent()).find(".shop-hesper-bd").children().length;
			Pcount = $(this.getPageContent()).find(".shop-hesper-bd .shop-filter .pagination .page-info").text().split("/")[1];
			Pcount = parseInt(Pcount);
			if(Pcount !== Pcount){
				casper.echo("总页数：" + Pcount,"COMMENT");
				casper.echo("页面出错重新加载","COMMENT");
				this.exit(1);
			}
			$(this.getPageContent()).find(".shop-hesper-bd").children().each(function(i){
				
				if($(this).attr("class") === "pagination"){
					sepNum = i;
				}

				casper.thenOpen(_url,function(){

					casper.wait(750,function(){});

				});

				
				casper.then(function(){
					if(i < sepNum && i > 0){
						var bdItems = $(this.getPageContent()).find(".shop-hesper-bd").children().eq(i).find(".item");
						console.log(bdItems.length + " ====== " + i);
						console.log(this.getCurrentUrl());

						if(i < itemLen && bdItems.length === 0){
							this.exit(1);
						}
						bdItems.each(function(m){
   							casper.then(function(){
   								casper.echo("任务："+_sname+"-获取第 " + pageNum + " 页,第 "+ ((i - 1) * 3 + m + 1) +" 个产品,总页数：" + Pcount, "INFO");
   								dataItem[1] = "http:" + bdItems.eq(m).find(".photo .J_TGoldData img").attr("src");
   								dataItem[2] = "taobao";
   								dataItem[5] = bdItems.eq(m).find(".item-name").text().trim();
								dataItem[6] = bdItems.eq(m).find(".cprice-area .c-price").text();
								dataItem[8] = bdItems.eq(m).find(".sale-area .sale-num").text();
								dataItem[9] = bdItems.eq(m).find(".title h4 a span").text();
								dataItem[11] = "http:" + bdItems.eq(m).find(".photo .J_TGoldData").attr("href");

								console.log("任务："+_sname+"-图片地址：" + dataItem[1]);
								console.log("任务："+_sname+"-宝贝名称：" + dataItem[5]);
								console.log("任务："+_sname+"-宝贝成交价格：" + dataItem[6]);
								console.log("任务："+_sname+"-总销售量：" + dataItem[8]);
								console.log("任务："+_sname+"-评价人数：" + dataItem[9]);
								console.log("任务："+_sname+"-宝贝详情地址：" + dataItem[11]);

								shopSalesCount += parseInt(dataItem[8]);
   							});

   							casper.wait(2000,function(){});
   							casper.then(function(){
   								casper.thenOpen(dataItem[11],function(){
   									casper.waitForSelectorTextChange("#J_RateCounter",function(){
   										dataItem[0] = $(this.getPageContent()).find("input[name='item_id_num']").val();
		   								dataItem[7] = $(this.getPageContent()).find("#J_SellCounter").text();
		   								dataItem[9] = $(this.getPageContent()).find("#J_RateCounter").text();
		   								$(this.getPageContent()).find(".attributes-list li").each(function(){
		   									if($(this).text().split(":")[0] === "品牌"){
		   										dataItem[3] = $(this).text().split(":")[1].trim();
		   										
		   										return false;
		   									}
		   								});
		   								
		   								console.log("任务："+_sname+"-商品编号：" + dataItem[0]);
		   								console.log("任务："+_sname+"-品牌名称：" + dataItem[3]);
		   								console.log("任务："+_sname+"-月销售量：" + dataItem[7]);
		   								console.log("任务："+_sname+"-评价数量：" + dataItem[9]);
   									},function(){
   										dataItem[0] = $(this.getPageContent()).find("input[name='item_id_num']").val();
		   								dataItem[7] = $(this.getPageContent()).find("#J_SellCounter").text();
		   								dataItem[9] = $(this.getPageContent()).find("#J_RateCounter").text();
		   								$(this.getPageContent()).find(".attributes-list li").each(function(){
		   									if($(this).text().split(":")[0] === "品牌"){
		   										dataItem[3] = $(this).text().split(":")[1].trim();
		   										
		   										return false;
		   									}
		   								});
		   								
		   								console.log("任务："+_sname+"-商品编号：" + dataItem[0]);
		   								console.log("任务："+_sname+"-品牌名称：" + dataItem[3]);
		   								console.log("任务："+_sname+"-月销售量：" + dataItem[7]);
		   								console.log("任务："+_sname+"-评价数量：" + dataItem[9]);
   									},2000);
   								});
   								casper.thenClick("a[shortcut-label='查看累计评论']");
   								casper.wait(1000,function(){
   									var hpr = $(this.getPageContent()).find(".content-regarded").text().replace("(","").replace(")","");
   									if(hpr === "" || hpr === "-"){
   										casper.echo("sdfadfads","WARNING");
   										casper.thenClick("a[shortcut-label='查看累计评论']");
   										casper.wait(1000,function(){
   											dataItem[10] = $(this.getPageContent()).find(".content-regarded").text().replace("(","").replace(")","");
		   									console.log("任务："+_sname+"-好评人数：" + dataItem[10]);
		   									casper.back();
   										});
   									}else{
   										dataItem[10] = $(this.getPageContent()).find(".content-regarded").text().replace("(","").replace(")","");
	   									console.log("任务："+_sname+"-好评人数：" + dataItem[10]);
	   									casper.back();
   									}
   									
   								});
   							});


   							

							casper.then(function(){
								xlsx_data.push(dataItem);
								dataItem = ["","","","","","","","","","","",""];
								pageCount++;
								casper.echo("=================产品分割线================","INFO");
							});
						});
					}else if(i >= sepNum && i > 0){
							return false;
					}
				});
				
			});
		}else{
			casper.echo("错误3：店铺类型","WARNING");
			this.exit(3);

			// shopType = 1;
			// var _url = [];
			// 	$(this.getPageContent()).find(".shop-hesper-bd ul.shop-list li").each(function(m){

			// 		// dataItem.push(pageCount);

			// 		dataItem.push($(this).find(".desc a").text().trim());
			// 		dataItem.push($(this).find(".price strong").text());
			// 		dataItem.push($(this).find(".sales-amount em").text());
			// 		dataItem.push($(this).find(".desc a").attr("href"));

			// 		xlsx_data.push(dataItem);
			// 		dataItem = ["","","","","","","","","","","",""];
			// 		pageCount++;
			// 	});
		}
	});

	casper.wait(500,function(){
		
		// console.log("任务"+ _sid +": 获取第 " + pageNum + " 页数据... 共 " + Pcount + "页");
		if(pageNum < Pcount){
			pageNum++;
			if(shopType == 1){
				listUrl = _surl + "&pageNo=" + pageNum;
			}else{
				listUrl = _surl + "&pageNum=" + pageNum;
			}
			
			casper.thenOpen(listUrl,function(){
				nextPage();
			});
		}else{

			casper.then(function(){
				ajax_countSales();
			});

			casper.then(function(){
				var i_json = {}, i_json_item = {};

				xlsx_data.forEach(function(res, i){
					res.forEach(function(resItem, j){
						i_json_item["child"+j] = resItem;
						i_json["root"+i] = i_json_item;
					});
					i_json_item = {};
				});
				// if(shopType == 1){
				// 	ajax_csv(i_json, _sname,"taobao_shop_month");
				// }else{4
					ajax_csv(i_json, _sname,"taobao_shop");
				// }
			});
			
			casper.wait(3000,function(){
				this.clear();
				casper.echo("店铺产品抓取完成！ 清理上下文！","INFO");
				this.exit(0);
			});
		}
	});
}

function tmallShop(_url){
	var sepNum = 0, itemLen = 0;
	casper.then(function(){
		itemLen = $(this.getPageContent()).find(".J_TItems").children().length;

		Pcount = $(this.getPageContent()).find("b.ui-page-s-len").text().split("/")[1];
		Pcount = parseInt(Pcount);
	// 	if(Pcount !== Pcount){
// 		console.log(this.getCurrentUrl())
// 			casper.echo("页面出错重新加载","COMMENT");
// 			this.exit(1);
// 		}

		$(this.getPageContent()).find(".J_TItems").children().each(function(i){
				
				if($(this).attr("class") === "pagination"){
					sepNum = i;
				}

				// dataItem.push(pageCount);
				casper.thenOpen(_url,function(){
					casper.wait(750,function(){});
				});



				casper.then(function(){
					if(i < sepNum){
						var bdItems = $(this.getPageContent()).find(".J_TItems").children().eq(i).find(".item");
						console.log(bdItems.length + " ====== " + i);
						if(bdItems.length == 0){
							
						}
						console.log(this.getCurrentUrl());
						if(i < itemLen && bdItems.length === 0){
							this.exit(1);
						}

						bdItems.each(function(m){
							casper.then(function(){
								casper.echo("任务："+_sname+"-获取第 " + pageNum + " 页,第 "+ (i * 5 + m + 1) +" 个产品,总页数：" + Pcount,"INFO");
// 								dataItem[1] = "http:" + bdItems.eq(m).find(".photo a img").attr("src");
								dataItem[1] = "http:" + bdItems.eq(m).find(".photo .J_TGoldData img").attr("data-ks-lazyload");
				   				dataItem[2] = "tmall";
								dataItem[5] = bdItems.eq(m).find(".item-name").text().trim();
								dataItem[6] = bdItems.eq(m).find(".c-price").text().trim();
								dataItem[8] = bdItems.eq(m).find(".sale-num").text();
								dataItem[9] = bdItems.eq(m).find(".rates .title h4 a span").text();
								dataItem[11] = "http:" + bdItems.eq(m).find(".item-name").attr("href");
								console.log(bdItems.eq(m).find(".photo .J_TGoldData img").html());
								console.log("任务："+_sname+"-图片地址：" + dataItem[1]);
								console.log("任务："+_sname+"-宝贝名称：" + dataItem[5]);
								console.log("任务："+_sname+"-宝贝成交价格：" + dataItem[6]);
								console.log("任务："+_sname+"-总销售量：" + dataItem[8]);
								console.log("任务："+_sname+"-评价人数：" + dataItem[9]);
								console.log("任务："+_sname+"-宝贝详情地址：" + dataItem[11]);
								shopSalesCount += parseInt(dataItem[8]);
							});
							casper.then(function(){
//    								casper.thenOpen(dataItem[11].replace("detail.tmall.com","detail.m.tmall.com"),function(){
                                 casper.thenOpen(dataItem[11].replace("detail.tmall.com","detail.tmall.com"),function(){
   									// this.scrollTo(0, 800);

   									console.log(this.getCurrentUrl());
   									if(this.getCurrentUrl().split("/")[2].split(".")[0] === "login"){
   										this.clear();
   										casper.echo("天猫受限，清除缓存重新连接...","WARNING");
   										this.exit(2);
   									}
   							// 		casper.waitForSelectorTextChange("#J_BrandAttr",function(){
										// dataItem[3] = $(this.getPageContent()).find(".J_EbrandLogo").text();
										// console.log("任务："+_sname+"-品牌名称：" + dataItem[3]);
   							// 		},function(){
										// dataItem[3] = $(this.getPageContent()).find(".J_EbrandLogo").text();
										// console.log("任务："+_sname+"-品牌名称：" + dataItem[3]);
   							// 		},3000);
// ---------------------------------------------------------------------------------------------------------------------------------------
   									// try {

   									// var _content_mdskip = this.getPageContent().split("_DATA_Mdskip = ")[1].split("<\/script>")[0];
            //     						_content_mdskip = eval('('+ _content_mdskip +')');


   									// dataItem[0] = getParName(this.getCurrentUrl(),"id");
		   							// dataItem[7] = _content_mdskip["defaultModel"]["sellCountDO"]["sellCount"];
		   							// // $(this.getPageContent()).find(".tm-ind-sellCount .tm-count,#J_indPanel .sales").text().replace("月销量 ","").replace("件","");
		   							// dataItem[9] = _content_mdskip["defaultModel"]["rateDO"]["rateCounts"];
		   							// // $(this.getPageContent()).find(".tm-ind-emPointCount .tm-count,.review b").text();
		   								
		   							// console.log("任务："+_sname+"-商品编号：" + dataItem[0]);
		   							// console.log("任务："+_sname+"-月销售量：" + dataItem[7]);
		   							// console.log("任务："+_sname+"-评价数量：" + dataItem[9]);

		   							// }catch(e){
		   							// 	console.log(e.message);
					       //              this.clear();
					       //              this.exit(2);
		   							// }
// ---------------------------------------------------------------------------------------------------------------------------------------		   							
   									casper.waitForSelectorTextChange("#J_RateCounter .tm-count",function(){
   										dataItem[0] = getParName(this.getCurrentUrl(),"id");
		   								dataItem[7] = $(this.getPageContent()).find(".tm-ind-sellCount .tm-count,#J_indPanel .sales").text().replace("月销量 ","").replace("件","");
		   								dataItem[9] = $(this.getPageContent()).find(".tm-ind-emPointCount .tm-count,.review b").text();
		   								
		   								console.log("任务："+_sname+"-商品编号：" + dataItem[0]);
		   								console.log("任务："+_sname+"-月销售量：" + dataItem[7]);
		   								console.log("任务："+_sname+"-评价数量：" + dataItem[9]);
		   								
   									},function(){
   										dataItem[0] = getParName(this.getCurrentUrl(),"id");
		   								dataItem[7] = $(this.getPageContent()).find(".tm-ind-sellCount .tm-count,#J_indPanel .sales").text().replace("月销量 ","").replace("件","");
		   								dataItem[9] = $(this.getPageContent()).find(".tm-ind-emPointCount .tm-count,.review b").text();
		   								
		   								console.log("任务："+_sname+"-商品编号：" + dataItem[0]);
		   								console.log("任务："+_sname+"-月销售量：" + dataItem[7]);
		   								console.log("任务："+_sname+"-评价数量：" + dataItem[9]);
   									},1000);
   								});

   							});

							casper.then(function(){
								casper.back();
							})

							casper.wait(2000,function(){});

							// casper.then(function(){
							// 	casper.thenOpen("http://www.taobao.com",function(){
							// 		casper.then(function(){
							// 			this.fill('form#J_TSearchForm', {
							// 			    'q':dataItem[5],
							// 		  	}, true);
							// 		});
							// 	});
   				// 			});

   				// 			casper.wait(1000,function(){

   				// 				this.scrollToBottom();
							// 	casper.wait(1000,function(){
							// 		$(this.getPageContent()).find(".m-itemlist .grid .items:first-child .item").each(function(){
							// 			if($(this).find(".ctx-box .title").text().trim() === dataItem[5] && $(this).find(".ctx-box .shop .shopname").text().trim() === _sww){
							// 				dataItem[4] = $(this).find(".deal-cnt").text().replace("人付款","");
							// 				console.log("任务："+_sname+"-付款人数：" + dataItem[4]);
							// 				return false;
							// 			}
							// 		});
							// 	});

							// 	casper.then(function(){
							// 		if(dataItem[4] === ""){
							// 			casper.thenOpen(this.getCurrentUrl() + "&loc=" + _sreg + "&filter=reserve_price%5B"+dataItem[6]+"%2C%5D", function(){
		   		// 							this.scrollToBottom();
		   		// 							casper.wait(1000,function(){
		   		// 								$(this.getPageContent()).find(".m-itemlist .grid .items:first-child .item").each(function(){
							// 						if($(this).find(".ctx-box .title").text().trim() === dataItem[5] && $(this).find(".ctx-box .shop .shopname").text().trim() === _sww){
							// 							dataItem[4] = $(this).find(".deal-cnt").text().replace("人付款","");
							// 							console.log("任务："+_sname+"-付款人数：" + dataItem[4]);
							// 							return false;
							// 						}
							// 					});
		   		// 							});
							// 			});
							// 		}
							// 	});

   								
							// });


							// casper.then(function(){
							// 	if(dataItem[4] === ""){
							// 		console.log("任务："+_sname+"-付款人数=：" + dataItem[4]);
							// 	}
							// });

							casper.then(function(){
								xlsx_data.push(dataItem);
// 								save(xlsx_data);
								dataItem = ["","","","","","","","","","","",""];
								pageCount++;
								casper.echo("=================产品分割线================","INFO");
							});
						});
					}else if(i >= sepNum && i > 0){
						return false;
					}
				});
		});
	});

	casper.wait(500,function(){
		
		// console.log("任务"+ _sid +": 获取第 " + pageNum + " 页数据... 共 " + Pcount + "页");
		// ajax_log(_sid, pageNum, Pcount, _sname);

	

		if(pageNum < Pcount){
			pageNum++;
			listUrl = _surl + "&pageNo=" + pageNum;

			casper.then(function(){
				var i_json = {}, i_json_item = {};
				xlsx_data.forEach(function(res, i){
					res.forEach(function(resItem, j){
						i_json_item["child"+j] = resItem;
						i_json["root"+i] = i_json_item;
					});
					i_json_item = {};
				});

				ajax_csv(i_json, _sname,"taobao_shop",pageNum);
			});

			casper.thenOpen(listUrl,function(){
				nextPage(true);
			});

		}else{
			casper.then(function(){
				ajax_countSales();
			});
			
			casper.wait(1500,function(){
				this.clear();
				casper.echo("店铺产品抓取完成！ 清理上下文！","INFO");
				this.exit(0);
			});
		}

	});
}

function ajax_csv(data_json,_name, csvType, _page){
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/csv", 
        data : { 
        	stype: csvType,
         	sname: _name,
         	snum : _page,
            val : JSON.stringify(data_json)
        },
        success : function(result){
            console.log("success!");
        }
    });
}

function ajax_countSales(){
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/countSales", 
        data : { 
         	sname: _sname,
            val : shopSalesCount
        },
        success : function(result){
            console.log("success!");
        }
    });
}
function save(save){
console.log(save)
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/save", 
        data : { 
            val : save
        },
        success : function(result){
            console.log("success!");
        }
    });
}
function replaceRegion(region){
	var sjmc = ["河北","河南","云南","辽宁","黑龙江","湖南","安徽","山东","新疆","江苏","浙江","江西","湖北","广西","甘肃","山西","内蒙","陕西","吉林","福建","贵州","广东","青海","西藏","四川","宁夏","海南","台湾","香港","澳门"];

	sjmc.forEach(function(res){
		region = region.replace(res,"");
	});
	console.log(region);

	return region;
}

function getParName(url,name) {
	var _reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var r = url.split("?")[1].match(_reg); 
	if (r != null) return unescape(r[2]); return "";
} 

casper.run();
