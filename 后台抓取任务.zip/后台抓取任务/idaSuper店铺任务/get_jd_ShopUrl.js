var fs = require('fs'), ms;
var $ = require('jquery');

ms = Date.now();

console.log("正在进入京东产品列表...");
var casper = require('casper').create({
    stepTimeout: 600000,
    waitTimeout: 600000
});

var defst = casper.cli;
var _shopUrl = defst.get("shopUrl"), _sname = defst.get("sname");


casper.start(_shopUrl, function() { 
   	casper.thenClick(".form input.button01");

   	casper.then(function(){
   		ajax_updUrl(this.getCurrentUrl(), _sname);
   	});
});


function ajax_updUrl(url, name){
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/updUrl", 
        data : {
            shopUrl : url,
            sName: name
        },
        success : function(result){
            console.log("success!");
        }
    });
}


casper.run();
