var http = require("http");
var querystring = require("querystring");
var fs = require("fs");
var exec = require('child_process').exec;
var _dts = {
    host: '183.134.100.27',
    port: "8888",
    url: "/idaplus-taskManager/taskmanager/getTask/shopTask.do"
};
// var _dts = {
// host: '192.168.10.28',
// port: "8083",
// url: "/idaplus-taskManager/taskmanager/getTask/shopTask.do"
// };
_dts["data"] = {
    taskType: 4,
    taskId: "",
    isSuccess: 1
};
_dts["_comment"] = {
    taskType: 12,
    taskId: "",
    isSuccess: 1
};
var overallId = "";
var overallIsSuccess = "";
var sFa = "";
var sSu = "";
var _sendts = {
    host: '183.134.100.130',
    port: "8888",
    url: "/idaplusweb/customer/shopinfomonitor/saveAttrShopData.do"
};
// var _send = {
//    host: '192.168.10.28',
//    port: "8081",
//    url:"/idaplus-centrePlatform-web/admin/review/saveTaskVo.do"
// };
var _send = {
    host: '183.134.100.130',
    port: "8888",
    url: "/idaplusweb/admin/review/saveTaskVo.do"
};
var _restart = "sudo poff";
var shopData = [], taskIDs = [];
var tm_shopInfo = "get_tmallShopInfo.js",
    tb_shopInfo = "get_taobaoShopInfo.js",
    tb_shopes = "get_taobaoTmall_shopDataes.js",
    tb_shop = "get_taobaoTmall_shopDataes.js";
//     tb_shop = "get_taobaoTmall_shopData.js";
var jd_shop = "getShopData_jd.js",
    jd_shopUrl = "get_jd_ShopUrl.js",
    jd_shopInfo = "get_jdShopInfo.js";
var offnet = "sudo networksetup -setnetworkserviceenabled PPPoE off";
var onnet = "sudo networksetup -setnetworkserviceenabled PPPoE on";
var connect = "networksetup -connectpppoeservice PPPoE";

var nextPage;

var taskName = [];
var taskShopItem = [];
var taskList = {};
var taskIDs = [];
var taskID = 0;
var logs = {};
var notesFile;
var succeed;
var _commentTask;
var save;
//var erro = [];
var csvNames = {
    "taobao_shop": ["goodId", "logoUrl", "platformId", "brandName", "payVolume", "goodsName", "goodsPrice", "monthSalesVolume", "allAssessVolume", "assessVolume", "favoriteCount", "detailUrl"],
};
// var _tData = {
//  "taskName" : "测试天猫111111",
//  "taskInfo": [{
//  "shopName": "huibojia",
// // "shopUrl": 'https://nuby.tmall.com/?spm=a220o.1000855.1997427721.d4918089.5c90c348jhVTkS',
//  "shopUrl": "https://huibojia.taobao.com/shop/view_shop.htm?spm=a230r.1.14.101.26fc93f9OLWf75&user_number_id=872921626"
// }],
// }
 var getTaskTimer = iTimer(true);//店铺任务
// AddTask(_tData);
// -------------------创建服务
http.createServer(function (request, response) {
    request.setEncoding('utf-8');
    response.setHeader('Access-Control-Allow-Origin', '*');
    var postData = "";
    request.addListener("data", function (postDataChunk) {
        postData += postDataChunk;
    });
    request.addListener("end", function () {
        var params = querystring.parse(postData);
        switch (request.url) {
            case "/setPar":
                setVal_jd(params["sName"], params["newNum"]);
                break;
            case "/updUrl":
                SetUrl(params["shopUrl"], params["sName"]);
                break;
            case "/setShopInfo":
                setSpInfo(params["val"], params["sname"]);
                break;
            case "/csv":
                expExcel(params["val"], params["sname"], params["stype"], params["pageNum"]);
                break;
            case "/countSales":
                countSales(params["val"], params["sname"]);
                break;
            case "/setTmShopInf":
                setTmShopInf(params["val"], params["number"]);
                break;
            case "/setJdShopInfo":
                setJdShopInfo(params["val"]);
                break;
            case "/setPage":
                nextPage = params["val"];
                break;
            case "/save":
                save = params;
                break;
        }
        response.end("数据接收完毕");
    });
}).listen(9010);
console.log("启动本地数据通道: 9010");
// ------------------店铺任务获取任务
function getTask(pdata, isSuccess) {
    if (isSuccess) {
        _dts["data"]["isSuccess"] = 1;
    } else {
        _dts["data"]["isSuccess"] = 0;
    }
    var str_data = querystring.stringify(_dts["data"]);
    console.log("taskParameter~~~~~~~~~" + querystring.stringify(_dts["data"]));
    var body = "";
    var options = {
        host: pdata["host"],
        path: pdata["url"],
        port: pdata["port"],
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(str_data)
        }
    };
    var req = http.request(options, function (res) {
        console.log("请求状态：" + res.statusCode);
        res.on('data', function (d) {
            body += d;
        }).on('end', function () {
            var _json;
            try {
                _json = JSON.parse(body);
                _dts["data"]["taskId"] = _json.taskId;
                if (_json.taskId) {
                    notesFile = "任务开始时间:" + new Date() + ", " + "任务ID:" + _json.taskId + ", " + "URL:" + _json.taskUrl + "\n";
                    try {
                        fs.readFileSync('test/teskData' + '.test', { encoding: 'utf-8' });
                    } catch (e) {
                        //fs.mkdirSync('./test', 0777);
                    }
                    fs.writeFileSync('test/teskData' + '.test', notesFile, { flag: 'a' });
                    notesFile = "";
                }
            } catch (e) {
                console.log("放弃一个错误.")
            }
            if (res.statusCode == 200) {
                if (body !== "" && _json.taskId !== null && _json.taskId !== "") {
                    if (boolInfo(_json.taskId)) {
                        console.log("任务" + _json.taskId + "重复！等待其他任务·····");
                        clearInterval(getTaskTimer);
                        _dts["data"]["taskId"] = _json.taskId;
                        getTaskTimer = iTimer(true);
                    } else {
                        analyTask(body);
                    }
                }
                if (_json.methodName !== "" && _json.methodName !== null && _json.methodName !== "") {
                    if (_json.methodName.split(",")[0] == "false") {
                        clearInterval(getTaskTimer);
                        _dts["data"]["taskId"] = _json.methodName.split(",")[1];
                        if (_json.methodName.split(",")[2] == "1") {
                            getTaskTimer = iTimer(true);
                        } else {
                            getTaskTimer = iTimer();
                        }
                    }
                }
            }
        });
    }).on('error', function (e) {
        console.log("请求错误: " + e.message);
    });
    req.write(str_data);
    req.end();
    _dts["data"]["taskId"] = "";
}

// ----------------dianpu发送
function sendTaskData(taskData, shopInfo) {
    var body = "";
    var data = {
        "shopData": JSON.stringify(shopInfo)
    };
    var _info = querystring.stringify(data);
    console.log(shopInfo);
    var options = {
        host: taskData["host"],
        path: taskData["url"],
        port: taskData["port"],
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(_info)
        }
    };
    var req = http.request(options, function (res) {
        res.on('data', function (d) {
            body += d;
        }).on('end', function () {
            if (body !== "") {
                var res = querystring.parse(body);
                if (res["result"] === "false" || res["result"] === false) {
                    console.log(body);
                    console.log("服务器接收数据失败！");
                } else {
                    console.log(body);
                    console.log("服务器接收数据成功！");
                }
            } else {
                console.log(body);
                consoel.log("未获取到返回数据！");
            }
        });
    }).on('error', function (e) {
        console.log("请求错误: " + e.message);
    });
    req.write(_info);
    req.end();
}

// ------------店铺任务获取封装对象
function analyTask(taskData) {
    var _data = JSON.parse(taskData);
    console.log(_data);
    console.log(_data.objectId + "=====");
    shopData.push({
        "taskName": _data.taskId,
        "taskInfo": [{
            "shopName": _data.taskId,
            "shopUrl": _data.taskUrl,
        }],
        "id": _data.taskId,
        "object_Id": _data.objectId === undefined ? 0 : _data.objectId,
        "create_taskId": _data["taskId"] = undefined ? 0 : _data["taskId"],
        "taskStateRecord": _data["taskStateRecord"] === undefined ? 0 : _data["taskStateRecord"]
    });
    if (shopData.length <= 3) {
        console.log(_data.taskType);
        console.log(typeof _data.taskType);
        if (_data.taskType == 10) {
            AddTaskBasis(shopData[0]);
            console.log("店铺任务");
        } else {
            console.log("普通任务");
            //             AddTaskBasis(shopData[0]);
            AddTask(shopData[0]);
        }
        clearInterval(getTaskTimer);
        console.log("接收到新任务，当前任务池等待任务数：" + shopData.length);
    }
}
// -------------店铺任务任务池
function AddTask(data) {
    if (taskIDs.length == 1) {
        console.log("任务已满，拒绝任务");
    } else {
        taskName.push(data.taskName);

        clearInterval(getTaskTimer);

        taskIDs.push(taskID);
        console.log("接收到新任务: " + data.taskName);

        _taskItem = shopInfoInit(data.taskName, data);

        console.log("开始任务！");
        console.log("当前任务数:" + taskIDs.length);
        console.log("任务池任务数：" + shopData.length);
        var _plat = distPlat(_taskItem["rootUrl"]);

        switch (_plat) {
            case "taobao":
                console.log("正站在连接淘宝...");
                _taskItem["shopFile"] = tb_shop;
                iCommand(tb_shopInfo, _taskItem["rootUrl"], data.taskName, function () {
                    _taskItem["rootUrl"] = "https://" + _taskItem["rootUrl"].split("/")[2] + "/search.htm?search=y";
                    _taskItem["rootUrl"] = _taskItem["rootUrl"].replace(/"/g, "");
                    iexec(data.taskName);
                });
                break;
            case "tmall":
                console.log("正站在连接天猫...");
                _taskItem["shopFile"] = tb_shop;
                iCommand(tm_shopInfo, _taskItem["rootUrl"], data.taskName, function () {
                    _taskItem["rootUrl"] = "https://" + _taskItem["rootUrl"].split("/")[2] + "/search.htm?search=y";
                    _taskItem["rootUrl"] = _taskItem["rootUrl"].replace(/"/g, "");
                    iexec(data.taskName);
                });
                break;
            case "jd":
                console.log("正站在连接京东...");
                _taskItem["shopFile"] = jd_shop;
                iCommand(jd_shopUrl, _taskItem["rootUrl"], data.taskName, function () {
                    iCommand(jd_shopInfo, _taskItem["rootUrl"], data.taskName, function () {
                        iexec(data.taskName);
                    });
                });
                break;
        }
    }
}

//获取店铺基础信息
function AddTaskBasis(data) {
    if (taskIDs.length == 1) {
        console.log("任务已满，拒绝任务");
    } else {
        taskName.push(data.taskName);

        taskIDs.push(taskID);
        console.log("接收到新任务: " + data.taskName);

        _taskItem = shopInfoInit(data.taskName, data);

        console.log("开始任务！");
        console.log("当前任务数:" + taskIDs.length);
        console.log("任务池任务数：" + shopData.length);
        var _plat = distPlat(_taskItem["rootUrl"]);
        switch (_plat) {
            case "taobao":
                console.log("正站在连接淘宝...");
                _taskItem["shopFile"] = tb_shopes;
                iCommand(tb_shopInfo, _taskItem["rootUrl"], data.taskName, function () {
                    _taskItem["rootUrl"] = "https://" + _taskItem["rootUrl"].split("/")[2].replace(/"/g, "");
                    _taskItem["rootUrl"] = _taskItem["rootUrl"] + "/search.htm?search=y";
                    _taskItem["rootUrl"] = _taskItem["rootUrl"].replace(/"/g, "").replace(/[\n]/ig, '');
                    console.log("rootUrl--------------------------------------");
                    console.log(_taskItem["rootUrl"]);
                    iexec(data.taskName);
                });
                break;
            case "tmall":
                console.log("正站在连接天猫...");
                _taskItem["shopFile"] = tb_shopes;
                iCommand(tm_shopInfo, _taskItem["rootUrl"], data.taskName, function () {
                    //                     _taskItem["rootUrl"] = "https://" + _taskItem["rootUrl"].split("/")[2].replace(/"/g, "") + "/search.htm?search=y";
                    _taskItem["rootUrl"] = "https://" + _taskItem["rootUrl"].split("/")[2].replace(/"/g, "");
                    _taskItem["rootUrl"] = _taskItem["rootUrl"] + "/search.htm?search=y";
                    _taskItem["rootUrl"] = _taskItem["rootUrl"].replace(/"/g, "").replace(/[\n]/ig, '');
                    console.log("rootUrl--------------------------------------");
                    console.log(_taskItem["rootUrl"]);
                    iexec(data.taskName);
                });
                break;
            case "jd":
                console.log("正站在连接京东...");
                _taskItem["shopFile"] = jd_shop;
                iCommand(jd_shopUrl, _taskItem["rootUrl"], data.taskName, function () {
                    iCommand(jd_shopInfo, _taskItem["rootUrl"], data.taskName, function () {
                        iexec(data.taskName);
                    });
                });
                break;
        }
    }
}
//--------------------------平台判断
function distPlat(url) {
    console.log(url);
    var _plat = url.split("/")[2].split(".");
    if (_plat.indexOf("www") > 0) {
        return "err";
    }
    if (_plat.indexOf("taobao") > 0 || _plat.indexOf("jiyoujia") > 0) {
        return "taobao";
    } else if (_plat.indexOf("tmall") > 0) {
        return "tmall";
    } else if (_plat.indexOf("jd") > 0) {
        return "jd";
    } else {
        console.log(_plat);
        return "other";
    }
}

function shopInfoInit(name, data) {
    var _taskItem = taskList[name] = {};
    _taskItem["taskInfo"] = data.taskInfo;
    _taskItem["defUrlIndex"] = 0;
    _taskItem["rootUrl"] = '"' + _taskItem.taskInfo[_taskItem.defUrlIndex].shopUrl.replace(/"/g, "") + '"';//----------------------------------------------
    _taskItem["rootNum"] = 1;
    _taskItem["rootProCount"] = 1;
    _taskItem["taskID"] = 0;
    _taskItem["_2taobao"] = 0;
    _taskItem["create_taskId"] = data["create_taskId"];
    _taskItem["object_Id"] = data["object_Id"];
    _taskItem["taskStateRecord"] = data["taskStateRecord"];
    return _taskItem;
}
function iCommand(comFile, url, tName, func) {
    var _dos = exec("casperjs " + comFile + " --shopUrl=" + url + " --sname=" + tName);
    _dos.stdout.on('data', function (data) {
        console.log(data);
    });

    _dos.stderr.on('data', function (data) {
        console.log('报错啦~~：\n' + data);
    });

    _dos.on('exit', function (code, plat, type) {
        if (code !== 0) {
            //  if(code == 3){
            //         console.log("店铺不存在....跳过！");
            //         	getTaskTimer = iTimer(true);
            //         }
            if (code === 2) {
                console.log("子进程受限退出，代码：" + code + "... 重新拨号 ...");
                _dts["data"]["taskId"] = tName;
                console.log(shopData.length);
                shopData.splice(0, 1);
                taskIDs = [];
                taskShopItem = [];
                clearInterval(getTaskTimer);
                getTaskTimer = iTimer(true);
                // setTimeout(function () {
//                     redialNet(offnet);
//                 }, 500);
//                 setTimeout(function () {
//                     redialNet(onnet);
//                 }, 3500);
//                 setTimeout(function () {
//                     redialNet(connect);
//                 }, 5000);
//                                 setTimeout(function () {
//                                     iCommand(comFile, url, tName, func);
//                                 }, 6000);
            } else {
                console.log("子进程非正常退出，代码：" + code);
                //                 iCommand(comFile, url, tName, func);
                setTimeout(function () {
                    redialNet(offnet);
                }, 500);
                setTimeout(function () {
                    redialNet(onnet);
                }, 3500);
                setTimeout(function () {
                    redialNet(connect);
                }, 5000);
                setTimeout(function () {
                    iCommand(comFile, url, tName, func);
                    // getTaskTimer = iTimer(true)
                }, 7000);
            }
        } else {
            console.log("子进程正常退出，代码：" + code);
            func();
        }
    });
}
// ----------------------店铺任务数据抓取启动
var unfettered;
function iexec(tName) {
    var data_s = 1;
    var _taskItem = taskList[tName];
    console.log(_taskItem.rootUrl);
    if (save) {
        data_s = save;
    }
    var _dos = exec("casperjs " + _taskItem.shopFile + " --surl=" + _taskItem.rootUrl + " --snum=" + _taskItem.rootNum + " --scount=" + _taskItem.rootProCount + " --sid=" + _taskItem.taskID + " --sww=" + _taskItem["shopInfo"]["wangWang"] + " --sreg=" + _taskItem["shopInfo"]["region"] + " --sname=" + tName + " --xy=" + _taskItem._2taobao);
    _dos.stdout.on('data', function (data) {
        console.log(data);
    });
    _dos.stderr.on('data', function (data) {
        console.log('报错啦~~：\n' + data);
    });
    _dos.on('exit', function (code, plat, type) {
        if (code !== 0) {
            if (code === 2) {
                console.log("子进程受限退出，代码：" + code + "... 重新拨号 ...");
                // setTimeout(function () {
//                     iexec(tName);
//                 }, 3000);
				setTimeout(function () {
                    redialNet(offnet);
                }, 500);
                setTimeout(function () {
                    redialNet(onnet);
                }, 3500);
                setTimeout(function () {
                    redialNet(connect);
                }, 5000);
                setTimeout(function () {
                    iexec(tName);
                }, 7000);
            } else {
                console.log("子进程非正常退出，代码：" + code);
                //                 taskList[tName]["rootNum"]++;
                setTimeout(function () {
                    redialNet(offnet);
                }, 500);
                setTimeout(function () {
                    redialNet(onnet);
                }, 3500);
                setTimeout(function () {
                    redialNet(connect);
                }, 5000);
                setTimeout(function () {
                    iexec(tName);
                }, 10000);
            }
        } else {
            console.log("子进程正常退出，代码：" + code);
            if (_taskItem.defUrlIndex < _taskItem.taskInfo.length - 1) {
                // shopComm(tName);
            } else {
                console.log("任务" + _taskItem.taskID + ": 所有产品检索完毕, 任务完成！");
                if (taskIDs.length > 0) {
                    taskList[tName]["shopInfo"]["shopItems"] = taskShopItem;
                    console.log(taskList[tName]["shopInfo"]);
                    console.log(taskList[tName]["shopInfo"]["platformId"])
                    _dts["data"]["taskId"] = tName;
                    sendTaskData(_sendts, taskList[tName]["shopInfo"]);
                    succeed = "任务完成时间:" + new Date() + ", " + "完成任务ID:" + tName + ", " + "完成任务URL" + _taskItem.rootUrl + "\n";
                    try {
                        fs.readFileSync('test/succeed' + '.text', { encoding: 'utf-8' });
                    } catch (e) {
                        //fs.mkdirSync('./test', 0777);
                    }
                    fs.writeFileSync('test/succeed' + '.text', succeed, { flag: 'a' });
                    succeed = "";
                    //delet("完成任务ID:"+tName);
                    shopData.splice(0, 1);
                    console.log("任务池释放一条运行任务，剩余数：" + shopData.length);
                    taskName = arrDel(taskName, tName);
                    taskIDs = arrDel(taskIDs, _taskItem.taskID);
                    taskList = jsonDel(taskList, tName);
                    logs = jsonDel(logs, tName);
                    taskShopItem = [];

                    if (shopData.length > 0) {
                        AddTaskBasis(shopData[0]);
                    }
                    if (taskIDs.length > 0) {
                        console.log("当前任务数:" + taskIDs.length);
                    } else {
                        save = "";
                        console.log("当前任务状态：空闲");
                        console.log("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                        setTimeout(function () {
                          redialNet(offnet);
                        }, 500);
                        setTimeout(function () {
                          redialNet(onnet);
                        }, 3500);
                       setTimeout(function () {
                         redialNet(connect);
                        }, 5000);
                       setTimeout(function () {
                         getTaskTimer = iTimer(true);
                       }, 6000);
                    }
                }

            }
        }
    });
}

function setSpInfo(shopInfo, tName) {
    taskList[tName]["shopInfo"] = JSON.parse(shopInfo);
    taskList[tName]["shopInfo"]["salesVol"] = 0;
    taskList[tName]["shopInfo"]["state"] = "1";
    taskList[tName]["shopInfo"]["create_taskId"] = taskList[tName]["create_taskId"];
    taskList[tName]["shopInfo"]["object_Id"] = taskList[tName]["object_Id"];
    taskList[tName]["shopInfo"]["taskStateRecord"] = taskList[tName]["taskStateRecord"];
}
function countSales(sales, tName) {

    if (sales !== sales || sales === undefined || sales === "" || sales === "NaN") {
        sales = 0;
    }
    taskList[tName]["shopInfo"]["salesVol"] = sales;
}

function expExcel(data, tName, type, page) {
    var _taskItem = taskList[tName];
    taskList[tName]["rootNum"] = page;
    var datares = JSON.parse(data);
    var rootArr = [], childArr = [];

    //if(_taskItem["rootNum"] == 1 && type !== undefined){
    rootArr = [csvNames[type]];
    //}

    for (dataroot in datares) {
        for (datachild in datares[dataroot]) {
            childArr.push(datares[dataroot][datachild]);
        }
        rootArr.push(childArr);
        childArr = [];
    }

    // var _shopItems = [];
    var _items = {};
    if (rootArr.length > 2) {
        rootArr.forEach(function (res, i) {
            if (i > 0) {
                res.forEach(function (item, m) {
                    _items[rootArr[0][m]] = item;
                });
                taskShopItem.push(_items);
                _items = {};
            }
        });
    }
    // taskShopItem = _shopItems;
};

function setVal_jd(tName, _inum) {
    taskList[tName]["rootNum"] = _inum;
}
function SetUrl(sUrl, tName) {
    taskList[tName]["rootUrl"] = '"' + sUrl + '"';
}

function arrDel(arr, str) {
    arr.forEach(function (res, i) {
        if (res === str) {
            arr.splice(i, 1);
        }
    });
    return arr;
}

function jsonDel(json, name) {
    var _json = {};

    for (jsonName in json) {
        if (jsonName !== name) {
            _json[jsonName] = json[jsonName];

        }
    }
    return _json;
}
function iTimer(mes) {
    return setInterval(function () {
        console.log("等待任务ing..." + mes);
        getTask(_dts, mes);
        mes = false;
    }, 10000);
}

function redialNet(mlh) {
    var netObj = exec(mlh);
    netObj.stdout.on('data', function (data) {
        console.log(data);
    });

    // 捕获标准错误输出并将其打印到控制台
    netObj.stderr.on('data', function (data) {
        console.log('报错啦~~：\n' + data);
    });
    // 注册子进程关闭事件
    netObj.on('exit', function (code, signal) {
        console.log("正在重启网络..." + code);
    });
}


function boolInfo(Id, type) {
    if (type == 12) {
        var fileDataSu12 = fs.readFileSync("test/succeed12.text", { encoding: "utf-8" }, function (err, data) {
            var dataSu12 = JSON.parse(data);
            return dataSu12;
        });
        console.log("-----------------+++" + Id);
        var lengthSu12 = fileDataSu12.split("\n").length;
        for (var i = 0; i < lengthSu12 - 1; i++) {
            if (fileDataSu12.split("\n")[i].split(",")[1].split(":")[1] == Id) {
                return true;
            }
        }
    } else {
        var fileDataSu = fs.readFileSync("test/succeed.text", { encoding: "utf-8" }, function (err, data) {
            var dataSu = JSON.parse(data);
            return dataSu;
        });
        var lengthSu = fileDataSu.split("\n").length;
        for (var i = 0; i < lengthSu - 1; i++) {
            //console.log("-----------------+++"+fileDataSu.split("\n")[i].split(",")[1].split(":")[1]);
            //console.log("-----------------++"+(fileDataSu.split("\n")[i].split(",")[1].split(":")[1] == Id));

            if (fileDataSu.split("\n")[i].split(",")[1].split(":")[1] == Id) {
                console.log("-----------------+++" + Id);
                return true;
            }
        }
    }

}
function taskNumber(_jId) {
    var count = 0;
    var fileDataMes = fs.readFileSync("test/mes.text", { encoding: "utf-8" }, function (err, data) {
        var dataMes = data.JSON.parse(data);
        return dataMes;
    });
    var lengthMes = fileDataMes.split("\n").length;
    for (var i = 0; i < lengthMes; i++) {
        if (_jId == fileDataMes.split("\n")[i].split(",")[1].split(":")[1]) {
            count++;
            if (count > 10) {
                return true;
            }
        }
    }
}