var fs = require('fs'), ms;
var $ = require('jquery');

ms = Date.now();

var casper = require('casper').create({
    stepTimeout: 60000,
    waitTimeout: 60000
});
casper.echo("正在获取天猫店铺信息....","INFO");
var defst = casper.cli;
var _shopUrl = defst.get("shopUrl"), _sname = defst.get("sname");
var _tbShopInfo = {
	platformId: "tmall",
	shopUrl: _shopUrl,
	promise: "",
	proFileUrl: "CSV宝贝文件磁盘路径"
};
casper.start(_shopUrl,function(){

	console.log(this.getCurrentUrl());

	casper.wait(2000,function(){
// 	console.log("--------------------------------------------")
// 	if($(this.getPageContent()).find("#content .error-notice-hd")){
// 	console.log("店铺不存在！")
// 		this.exit(0);
// 	}
		casper.then(function(){

			var pop = $(this.getPageContent()).find(".extra-info textarea");
			var _hk = pop.length == 0 ? true : false;
			pop = _hk ? $(this.getPageContent()).find(".hd-shop-popup") : $(pop.val());

			console.log(_hk);

			_tbShopInfo["shopId"] = this.getElementAttribute('div#LineZing', 'shopid');
			_tbShopInfo["shopName"] = $(this.getPageContent()).find(".slogo-shopname,.hd-shop-name a").text();
			_tbShopInfo["wangWang"] = "";
			// pop.find(".shopkeeper .right").text().trim();

			console.log("店铺id：" + _tbShopInfo["shopId"]);
			console.log("店铺名：" + _tbShopInfo["shopName"]);
			console.log("旺旺id：" + _tbShopInfo["wangWang"]);
			if(_tbShopInfo["shopId"]== ""||_tbShopInfo["shopId"]==null){
				console.log("放弃此条任务！");
			this.exit(2);
			}


			// var _itemScrib_rdRate = _content.find(".dsr-info .J_RateInfoTrigger:nth-child(1) .item-scrib"),
			// 	_itemScrib_fwRate = _content.find(".dsr-info .J_RateInfoTrigger:nth-child(2) .item-scrib"),
			// 	_itemScrib_dsRate = _content.find(".dsr-info .J_RateInfoTrigger:nth-child(3) .item-scrib");

			var _itemScrib_rdRate = pop.find("ul li:nth-child(1),dl.tb-shop-score-state dd:nth-child(1)"),
				_itemScrib_fwRate = pop.find("ul li:nth-child(2),dl.tb-shop-score-state dd:nth-child(2)"),
				_itemScrib_dsRate = pop.find("ul li:nth-child(3),dl.tb-shop-score-state dd:nth-child(3)");

			console.log(pop.find("dl.tb-shop-score-state dd:nth-child(1) b").text());
			console.log(_itemScrib_dsRate.find("b").text() + " 123123");

			_tbShopInfo["rank"] = pop.find(".tm-shop-age-content").eq(0).text();
			_tbShopInfo["mainProducts"] = "";
			 // _content.find(".col-sub .left-box:first-child .bd ul li:first-child a").text().trim();
			_tbShopInfo["praiseRate"] = "";
			 // _content.find(".box-shadow-combo h4 em").text().replace("好评率：","");
			_tbShopInfo["rdRate"] = _itemScrib_rdRate.find("em.count, b").text();
			_tbShopInfo["rdHigherRate"] = _hk ? score(_itemScrib_rdRate) : score(_itemScrib_rdRate.find(".rateinfo"));
			_tbShopInfo["fwRate"] = _itemScrib_fwRate.find("em.count, b").text();
			_tbShopInfo["fwHigherRate"] = _hk ? score(_itemScrib_fwRate) : score(_itemScrib_fwRate.find(".rateinfo"));
			_tbShopInfo["dsRate"] = _itemScrib_dsRate.find("em.count, b").text();
			_tbShopInfo["dsHigherRate"] = _hk ? score(_itemScrib_dsRate) : score(_itemScrib_dsRate.find(".rateinfo"));


			console.log("店铺等级：" + _tbShopInfo["rank"]);
			console.log("主营：" + _tbShopInfo["mainProducts"]);
			console.log("好评率：" + _tbShopInfo["praiseRate"]);
			console.log("描述相符率：" + _tbShopInfo["rdRate"]);
			console.log("服务态度：" + _tbShopInfo["fwRate"]);
			console.log("物流服务：" + _tbShopInfo["dsRate"]);
			console.log("描述相符与同行业相比：" + _tbShopInfo["rdHigherRate"]);
			console.log("服务态度与同行业相比：" + _tbShopInfo["fwHigherRate"]);
			console.log("物流服务与同行业相比：" + _tbShopInfo["dsHigherRate"]);
			console.log("店铺请求地址："+ _tbShopInfo["shopUrl"]);

		});
	});

	casper.thenOpen("http://shopsearch.taobao.com/browse/shop_search.htm",function(){
		// casper.then(function(){
		// 	 this.mouseEvent("click","#J_SearchTab ul li[data-searchtype='shop']");
		// });
		// casper.thenEvaluate(function(){
		// 	document.querySelector('form#J_TSearchForm').setAttribute('action', "//shopsearch.taobao.com/browse/shop_search.htm");
		// });

		casper.then(function(){
			this.fill('form#J_SearchForm', {
			    'q':_tbShopInfo["shopName"],
		  	}, true);
		});
		casper.wait(1000,function(){});
		casper.then(function(){
			$(this.getPageContent()).find("#list-container li.list-item").each(function(){
				if($(this).find(".list-info h4 a").text().trim() === _tbShopInfo["shopName"]){
					_tbShopInfo["logoUrl"] = "http:" + $(this).find(".list-img img").attr("src");
					console.log("店铺log：" + _tbShopInfo["logoUrl"]);
					return false;
				}
			});
		});
	});
	// casper.thenOpen("http:" + pop.find(".shop-rate ul li").eq(0).find("a").attr("href"),function(){


		// var _content = $(this.getPageContent());
		
		

	// });
	//casper.then(function(){
	//	_tbShopInfo["region"] = "";
	//});
	casper.thenOpen("https://" + _tbShopInfo["shopUrl"].split("/")[2] + "/search.htm?search=y",function(){
		console.log("---------------------------1");
		if(_tbShopInfo["shopUrl"].split("/")[2].indexOf("hk") > 0){
			var items = $(this.getPageContent()).find(".J_TItems").children();
			var _itemurl = "https:" + items.eq(parseInt(Math.random() * items.length)).find(".item").eq(parseInt(Math.random() * 3)).find(".photo .J_TGoldData").attr("href");
			console.log(_itemurl);

// 			_itemurl = _itemurl.replace("detail.tmall.hk","detail.m.tmall.hk").replace("\/hk","");
			_itemurl = _itemurl.replace("\/hk","");

			casper.thenOpen(_itemurl,function(){

				console.log(this.getCurrentUrl());
				try{
					// var _content_mdskip = this.getPageContent().split("_DATA_Mdskip = ")[1].split("<\/script>")[0];
//                 	_content_mdskip = eval('('+ _content_mdskip +')');
//                 	console.log(123);
// 					// casper.wait(8000,function(){
// 					_tbShopInfo["region"] = _content_mdskip["defaultModel"]["deliveryDO"]["deliveryAddress"];
					_tbShopInfo["region"] = $(this.getPageContent()).find("#J_deliveryAdd").text().trim();
					if(_tbShopInfo["region"] === "" || _tbShopInfo["region"] === undefined){
	                    console.log("地区未找到重启！");
	                    this.clear();
	                    this.exit(1);
               		}
					console.log("地区：" + _tbShopInfo["region"]);
					// });
				}catch(e){
					 console.log("受限重启!");
					 this.clear();
					 this.exit(2);
				}

			});
		}else{
			casper.waitForSelectorTextChange("#bd",function(){
		console.log("------111");
			var items = $(this.getPageContent()).find(".J_TItems").children();
			// var _itemurl = "https:" + items.eq(parseInt(Math.random() * items.length)).find(".item").eq(parseInt(Math.random() * 3)).find(".photo .J_TGoldData").attr("href").replace("detail.tmall.com","detail.m.tmall.com");
			console.log("-----------------------------");
			console.log(items.eq(parseInt(Math.random() * items.length)));
		
			var _itemurl = "https:" + items.eq(parseInt(Math.random() * items.length)).find(".item").find(".photo .J_TGoldData").attr("href").replace("detail.tmall.com","detail.tmall.com");
			console.log(_itemurl);
			casper.thenOpen(_itemurl,function(){
				console.log(this.getCurrentUrl());
				try{
					// var _content_mdskip = this.getPageContent().split("_DATA_Mdskip = ")[1].split("<\/script>")[0];
//                 	_content_mdskip = eval('('+ _content_mdskip +')');
//                 	console.log(123);
// 					// casper.wait(8000,function(){
// 					_tbShopInfo["region"] = _content_mdskip["defaultModel"]["deliveryDO"]["deliveryAddress"];
					_tbShopInfo["region"] = $(this.getPageContent()).find("#J_deliveryAdd").text().trim();
					if(_tbShopInfo["region"] === "" || _tbShopInfo["region"] === undefined){
	                    console.log("地区未找到重启！");
	                    this.clear();
	                    this.exit(1);
               		}
					console.log("地区：" + _tbShopInfo["region"]);
					// });
				}catch(e){
					 console.log("受限重启!");
					 this.clear();
					 this.exit(2);
				}
			});
		});
		}
	});
	casper.then(function(){
		ajax_setShopInfo(_tbShopInfo);
	});
	casper.wait(1000,function(){});
});

function score(scoreobj){
	switch(scoreobj.find("b").attr("class")){
		case "fair": 
			return "持平--";
			break;
		case "lower":
			return "低于" + scoreobj.find("em").text();
			break;
		default:
			return "高于" + scoreobj.find("em").text();
			break;
	}
}
function ajax_setShopInfo(data_json){
    $.ajax({  
        type : "post",
        url : "http://127.0.0.1:9010/setShopInfo", 
        data : { 
         	sname: _sname,
            val : JSON.stringify(data_json)
        },
        success : function(result){
            console.log("success!");
        }
    });
}

casper.run();

