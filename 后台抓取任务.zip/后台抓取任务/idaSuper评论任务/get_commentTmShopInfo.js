var $ = require('jquery');
ms = Date.now();
var casper = require('casper').create({
    stepTimeout: 60000,
    waitTimeout: 60000
});
casper.echo("正在淘宝店铺信息....", "INFO");
var defst = casper.cli;
var _shopUrl = defst.get("surl");
var _PTN = defst.get("PTN");
var s = _PTN || 2;
var sumPage;
var pageNum;
casper.start(_shopUrl, function () {
    casper.wait(1500, function () {
    });
    casper.then(function () {
        sumPage = "https:" + $(this.getPageContent()).find(".all-cats-trigger a").attr("href")|| "https:" + $(this.getPageContent()).find(".J_TCatsTree a.cat-name.fst-cat-name").attr("href");
        aa(sumPage);
    });
    function aa(_surl) {
        casper.thenOpen(_surl, function () {
            casper.wait(1500, function () {
            });
            casper.then(function(){
                pageNum = $(this.getPageContent()).find(".pagination .page-info").text().split("/")[1];
                console.log("淘宝进入！"+this.getCurrentUrl());
                console.log("总页数："+pageNum);
                if(!pageNum){
                this.exit(0);
            }
            });
            casper.then(function () {
                var items = $(this.getPageContent()).find("dl.item");
                items.each(function(i){
                    casper.then(function(){
                            var _tbShopInfo = {
                                goodName: "",
                                pTrid: "",
                                picUrl: "",
                                url: "",
                            };
                            _tbShopInfo["goodName"] = $(this.getPageContent()).find(".item .item-name").eq(i).text().trim();
                            _tbShopInfo["pTrid"] = $(this.getPageContent()).find("dl.item").eq(i).attr("data-id");
                            _tbShopInfo["picUrl"] ="https:" + $(this.getPageContent()).find(".photo a img").eq(i).attr("src");
                            _tbShopInfo["url"] ="https:" + $(this.getPageContent()).find(".photo a").eq(i).attr("href");
                            ajax_setShopInfo(_tbShopInfo);
                    });
                    casper.wait(3000, function () {
                    });
                });
            });
            casper.wait(2000, function () {
            });
            casper.then(function () {
                var listUrl = sumPage + "&pageNo=" + s;
                if(!pageNum>0){
                    console.log("页面出错！");
                    this.exit(2)
                }
                if (s > pageNum) {
                    this.exit(0);
                    console.log("完成！！");
                } else {
                    console.log("进入！");
                    aa(listUrl);
                    console.log("nnnnnnn" + s);
                    s++;
                }
            })
        })
    }
});


function ajax_setShopInfo(_ShopInfo) {
    $.ajax({
        type: "post",
        url: "http://127.0.0.1:9010/setTmShopInf",
        data: {
            val: JSON.stringify(_ShopInfo),
            number:s
        },
        success: function (result) {
//             console.log("success!");
        }
    });
}

casper.run();
