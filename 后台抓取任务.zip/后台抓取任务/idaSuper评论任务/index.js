const $ = require("jquery");

$.ajax({
        type: "post",
        url: "http://183.134.100.130:8888/idaplusweb/admin/review/saveTaskVo.do",
        data: JSON.stringify({ shopData: '{"objectId":"5181485","pTrid":"557090549344","phraseFields":"{\\"taobaoReview\\":1}","taskName":"店铺评论任务","taskPlatfromType":"taobaoReview","taskUrl":"https://detail.tmall.com/item.htm?id=557090549344&rn=9ba0eb9ea53b5c92f8337cc7610785a8&abbucket=14","userId":1083,"note":"{\\"url\\":\\"https://detail.tmall.com/item.htm?id=557090549344&rn=9ba0eb9ea53b5c92f8337cc7610785a8&abbucket=14\\",\\"goodName\\":\\"Macro/万家乐 JSQ22-T11 天然气燃气热水器家用电11升液化气12\\",\\"picUrl\\":\\"https://img.alicdn.com/bao/uploaded/i4/2817558136/TB155r_d6gy_uJjSZLeXXaPlFXa_!!0-item_pic.jpg_180x180.jpg\\",\\"keyWordId\\":31}"}' }),
        
        success: function (result) {
            console.log(result)
        }
})