var $ = require('jquery');
var casper = require('casper').create({
    stepTimeout: 60000,
    waitTimeout: 60000
});
casper.echo("正在获取京东信息....", "INFO");
var defst = casper.cli;
var _shopUrl = defst.get("surl");
var spage = 2;
var _jdShopInfo;
console.log(_shopUrl);
casper.start(_shopUrl, function () {
    casper.wait(500, function () {
    });
    casper.then(function(){
        if($(this.getPageContent()).find(".form input.button01")){
            casper.thenClick(".form input.button01");
        }else{
            casper.thenClick("button.fl");
        }
    });
    //casper.thenClick(".form input.button01");
    casper.then(function(){
        nextPage(this.getCurrentUrl());
        console.log(this.getCurrentUrl())
    });

});
function nextPage(nextUrl) {
    casper.thenOpen(nextUrl, function () {
        casper.wait(500, function () {
        });
        casper.then(function(){
            console.log(this.getCurrentUrl());
            $(this.getPageContent()).find(".jSubObject .jItem").each(function(res){
                casper.then(function(){
                    _jdShopInfo = {
                        shopUrl: _shopUrl,
                        url:"",
                        goodName: "",
                        pTrid: "",
                        picUrl: ""
                    };
                    _jdShopInfo["url"] ="https:" + $(this.getPageContent()).find(".jSubObject .jItem .jPic a").eq(res).attr("href");
                    _jdShopInfo["goodName"] = $(this.getPageContent()).find(".jDesc a").eq(res).text().trim();
                    _jdShopInfo["pTrid"] = _jdShopInfo["url"].split("/")[3].split(".")[0];
                    _jdShopInfo["picUrl"] ="https:" +  $(this.getPageContent()).find(".jPic a img").eq(res).attr("src");
                    if(_jdShopInfo["pTrid"] ==""||_jdShopInfo["pTrid"]==undefined){
                        return true;
                    }else{
                        console.log(_jdShopInfo["pTrid"])
                    }
                });
                casper.then(function () {
                    ajax_setShopInfo(_jdShopInfo)
                });
            })
        });
        casper.then(function(){
            var nnm = $(this.getPageContent()).find(".jPage>a:nth-of-type("+spage+")").text().trim();
            console.log("ee"+nnm);
            if(isNaN(nnm)||nnm==""||nnm == undefined){
                exit(0);
            }else{
                nextPage("https:"+$(this.getPageContent()).find(".jPage>a:nth-of-type("+spage+")").attr("href"));
                console.log("进入"+$(this.getPageContent()).find(".jPage>a:nth-of-type("+spage+")").attr("href"));
                spage++;
                if(spage==3){
                    spage++;
                }
            }
        })
    })
}
function ajax_setShopInfo(_ShopInfo) {
    $.ajax({
        type: "post",
        url: "http://127.0.0.1:9010/setJdShopInfo",
        data: {
            val: JSON.stringify(_ShopInfo)
        },
        success: function (result) {
//             console.log("success!");
        }
    });
}

casper.run();
