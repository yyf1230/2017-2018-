var $ = require('jquery');
ms = Date.now();
var casper = require('casper').create({
    stepTimeout: 60000,
    waitTimeout: 60000
});
casper.echo("正在获取天猫店铺列表数据....", "INFO");
var defst = casper.cli;
var _shopUrl = defst.get("surl");
var s = 2;
var sumPage;
var pageNum;
casper.start(_shopUrl, function () {
    casper.wait(1500, function () {
    });
    casper.then(function () {
        sumPage = "http:" + $(this.getPageContent()).find(".skin-box-bd .all-cats-trigger a.link").attr("href");
        //console.log(sumPage);
        aa(sumPage);
    });
    function aa(_surl) {
        casper.thenOpen(_surl, function () {
            casper.wait(1500, function () {
            });
            casper.then(function () {
                console.log("天猫进入！" + this.getCurrentUrl());
                pageNum = $(this.getPageContent()).find(".ui-page-s-len").text().trim().split("/")[1];
                console.log("==================总页数=======================" + pageNum)
            });
            casper.then(function () {
                var items = $(this.getPageContent()).find("dl.item");
                items.each(function (i) {
                    casper.then(function () {
                        var _tbShopInfo = {
                            goodName: "",
                            pTrid: "",
                            picUrl: "",
                            url: "",
                        };
                        _tbShopInfo["goodName"] = $(this.getPageContent()).find(".J_TItems .item .item-name").eq(i).text().trim();
                        _tbShopInfo["pTrid"] = $(this.getPageContent()).find(".J_TItems .item").eq(i).attr("data-id");
                        _tbShopInfo["picUrl"] = "https:" + $(this.getPageContent()).find(".item .photo img").eq(i).attr("src");
                        if ($(this.getPageContent()).find(".item .photo img").eq(i).attr("data-ks-lazyload")) {
                            _tbShopInfo["picUrl"] = "https:" + $(this.getPageContent()).find(".item .photo img").eq(i).attr("data-ks-lazyload");
                        }
                        _tbShopInfo["url"] = "https:" + $(this.getPageContent()).find(".item .photo a").eq(i).attr("href");
                        ajax_setShopInfo(_tbShopInfo);
                    });
                    casper.wait(5000, function () {
                    });
                });
            });
            casper.wait(3000, function () {
            });
            casper.then(function () {
                var listUrl = sumPage + "&pageNo=" + s;
                if (!pageNum > 0) {
                    ajax_page(s)
                    console.log("页面出错！");
                    this.exit(2)
                }
                if (s > pageNum) {
                    this.exit(0);
                    console.log("完成！！");
                } else {
                    console.log("进入！");
                    aa(listUrl);
                    console.log("nnnnnnn" + s);
                    s++;
                }
            })
        })
    }
});
function ajax_setShopInfo(_ShopInfo) {
    $.ajax({
        type: "post",
        url: "http://127.0.0.1:9010/setTmShopInf",
        data: {
            val: JSON.stringify(_ShopInfo)
        },
        success: function (result) {
            //             console.log("success!");
        }
    });
}
function ajax_page(_page) {
    $.ajax({
        type: "post",
        url: "http://127.0.0.1:9010/setPage",
        data: {
            val: JSON.stringify(_page)
        },
        success: function (result) {
            console.log("===============================受限拨号!");
        }
    });
}
casper.run();
