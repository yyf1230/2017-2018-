﻿var http = require("http");
var querystring = require("querystring");
var fs = require("fs");
var exec = require('child_process').exec;
var _dts = {
    host: '183.134.100.27',
    port: "8888",
    url: "/idaplus-taskManager/taskmanager/getTask/shopTask.do"
};
// var _dts = {
// host: '192.168.10.28',
// port: "8083",
// url: "/idaplus-taskManager/taskmanager/getTask/shopTask.do"
// };
_dts["data"] = {
    taskType: 4,
    taskId: "",
    isSuccess: 1
};
_dts["_comment"] = {
    taskType: 12,
    taskId: "",
    isSuccess: 1
};
var overallId = "";
var overallIsSuccess = "";
var sFa = "";
var sSu = "";
var _sendts = {
    host: '183.134.100.130',
    port: "8888",
    url: "/idaplusweb/customer/shopinfomonitor/saveAttrShopData.do"
};
// var _send = {
//    host: '192.168.10.28',
//    port: "8081",
//    url:"/idaplus-centrePlatform-web/admin/review/saveTaskVo.do"
// };
var _send = {
    host: '183.134.100.130',
    port: "8888",
    url: "/idaplusweb/admin/review/saveTaskVo.do"
};
var _restart = "sudo poff";
var shopData = [], taskIDs = [];
var tm_shopInfo = "get_tmallShopInfo.js",
    tb_shopInfo = "get_taobaoShopInfo.js",
    tb_shopes = "get_taobaoTmall_shopDataes.js",
    tb_shop = "get_taobaoTmall_shopDataes.js";
// tb_shop = "get_taobaoTmall_shopData.js";
var jd_shop = "getShopData_jd.js",
    jd_shopUrl = "get_jd_ShopUrl.js",
    jd_shopInfo = "get_jdShopInfo.js";
var comment_tmShopInfo = "get_commentTmShopInfo.js",
    comment_tmInfo = "get_commentTmInfo.js",
    comment_jdShopInfo = "get_commentJdShopInfo.js",
    comment_jdShopInfo2 = "get_commentJdShopInfo2.js";

var offnet = "sudo networksetup -setnetworkserviceenabled PPPoE off";
var onnet = "sudo networksetup -setnetworkserviceenabled PPPoE on";
var connect = "networksetup -connectpppoeservice PPPoE";

var nextPage;

var taskName = [];
var taskShopItem = [];
var taskList = {};
var taskIDs = [];
var taskID = 0;
var logs = {};
var notesFile;
var succeed;
var _commentTask;
var save;
//var erro = [];
var csvNames = {
    "taobao_shop": ["goodId", "logoUrl", "platformId", "brandName", "payVolume", "goodsName", "goodsPrice", "monthSalesVolume", "allAssessVolume", "assessVolume", "favoriteCount", "detailUrl"],
};
var getTaskTimer12 = iTimer12(true);//评论任务
// -------------------创建服务
http.createServer(function (request, response) {
    request.setEncoding('utf-8');
    response.setHeader('Access-Control-Allow-Origin', '*');
    var postData = "";
    request.addListener("data", function (postDataChunk) {
        postData += postDataChunk;
    });
    request.addListener("end", function () {
        //console.log('数据接收完毕');
        var params = querystring.parse(postData);
        switch (request.url) {
            case "/setPar":
                setVal_jd(params["sName"], params["newNum"]);
                break;
            case "/updUrl":
                SetUrl(params["shopUrl"], params["sName"]);
                console.log("接受到了店铺url");
                break;
            case "/setShopInfo":
                setSpInfo(params["val"], params["sname"]);
                break;
            case "/csv":
                expExcel(params["val"], params["sname"], params["stype"], params["snum"]);
                break;
            case "/countSales":
                countSales(params["val"], params["sname"]);
                break;
            case "/setTmShopInf":
                setTmShopInf(params["val"], params["number"]);
                break;
            case "/setJdShopInfo":
                setJdShopInfo(params["val"]);
                break;
            case "/setPage":
                nextPage = params["val"];
                break;
            case "/save":
                save = params;
                console.log("---------------------------------/save");
                console.log(params["val[0][]"]);
                break;
        }
        response.end("数据接收完毕");
    });
}).listen(9010);
console.log("启动本地数据通道: 9010");
// -------------评论任务获取任务
function getCom_Task(pdata, isSuccess) {
    if (isSuccess) {
        _dts["_comment"]["isSuccess"] = 1;
    } else {
        _dts["_comment"]["isSuccess"] = 0;
    }
    var _commentData = querystring.stringify(_dts["_comment"]);
    var body = "";
    var options = {
        host: pdata["host"],
        path: pdata["url"],
        port: pdata["port"],
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(_commentData)
        }
    };
    var request = http.request(options, function (res) {
        console.log("请求状态12：" + res.statusCode);
        res.on('data', function (d) {
            if (res.statusCode == 200)
                body += d;
        }).on('end', function () {
            var _json;
            try {
                _json = JSON.parse(body);
                console.log("_json.methodName12·····" + _json.methodName);
                if (_json.taskId) {
                    var notesFile12 = "任务开始时间:" + new Date() + ", " + "任务ID:" + _json.taskId + ", " + "URL:" + _json.taskUrl + "\n";
                    try {
                        fs.readFileSync('test/mes12' + '.test', { encoding: 'utf-8' });
                    } catch (e) {
                        //fs.mkdirSync('./test', 0777);
                    }
                    fs.writeFileSync('test/mes12' + '.test', notesFile12, { flag: 'a' });
                }
            } catch (e) {
                console.log("放弃一个错误.")
            }
            if (body !== "" && _json.taskId !== null && _json.taskId !== "") {
                clearInterval(getTaskTimer12);
                analyzeTask(body);
            }
        });
    }).on('error', function (e) {
        console.log("请求错误: " + e.message);
    });
    request.write(_commentData);
    request.end();
    _dts["_comment"]["taskId"] = "";
}
function sendTask(comTask) {
    var body = "";
    var data = {
        "shopData": JSON.stringify(comTask)
    };
    var _info = querystring.stringify(data);
    console.log("发送数据----!");
    console.log(querystring.parse(_info));
    //record(querystring.parse(_info));
    var options = {
        host: _send["host"],
        path: _send["url"],
        port: _send["port"],
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(_info)
        }
    };
    var reques = http.request(options, function (res) {
        res.on('data', function (d) {
            body += d;
        }).on('end', function () {
            if (body !== "") {
                var res = querystring.parse(body);
                if (res["result"] === "false" || res["result"] === false) {
                    console.log(body);
                    console.log("服务器接收数据失败！");
                } else {
                    console.log("接收返回----!" + body);
                    console.log("服务器接收数据成功！");
                    _commentTask["note"] = {};
                    //getTaskTimer12 = iTimer12(true);
                }
            } else {
                console.log(body);
                console.log("未获取到返回数据！");
            }
        });
    }).on('error', function (e) {
        console.log("请求错误: " + e.message);
    });
    reques.write(_info);
    reques.end();
}

// ----------------dianpu发送
function sendTaskData(taskData, shopInfo) {
    var body = "";
    var data = {
        "shopData": JSON.stringify(shopInfo)
    };
    var _info = querystring.stringify(data);
    console.log(shopInfo);
    var options = {
        host: taskData["host"],
        path: taskData["url"],
        port: taskData["port"],
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(_info)
        }
    };
    var req = http.request(options, function (res) {
        res.on('data', function (d) {
            body += d;
        }).on('end', function () {
            if (body !== "") {
                var res = querystring.parse(body);
                if (res["result"] === "false" || res["result"] === false) {
                    console.log(body);
                    console.log("服务器接收数据失败！");
                } else {
                    console.log(body);
                    console.log("服务器接收数据成功！");
                }
            } else {
                console.log(body);
                consoel.log("未获取到返回数据！");
            }
        });
    }).on('error', function (e) {
        console.log("请求错误: " + e.message);
    });
    req.write(_info);
    req.end();
}
// --------------评论任务获取生成对象
var _datataskUrl;
var _dataobjectId;
function analyzeTask(taskData) {
    console.log(JSON.parse(taskData));
    var _data = JSON.parse(taskData);
    console.log(_data.taskId);
    console.log("---" + _data);
    _datataskUrl = _data.taskUrl;
    _dataobjectId = _data.objectId;
    _commentTask = {
        "objectId": _data.taskId,
        "pTrid": "",
        "phraseFields": "", //必填  （淘宝 ：{taobaoReview:1} 京东：{jingdongReview:1}）
        "taskName": _data.taskName,
        "taskPlatfromType": "", //必填  (淘宝：taobaoReview   京东：jingdongReview)
        "taskUrl": "",  //必填 宝贝地址
        "userId": _data.userId  //必填 用户id
    };
    console.log("评论任务");
    console.log("接收到了新任务:" + _data.objectId);
    addTaskComment();
}
//-------------------进行评论任务
function addTaskComment(next) {
    var _plat = distPlat(_datataskUrl);
    switch (_plat) {
        case "taobao":
            _commentTask["phraseFields"] = '{"taobaoReview":1}';
            _commentTask["taskPlatfromType"] = "taobaoReview";
            commentExec(comment_tmShopInfo);
            break;
        case "tmall":
            _commentTask["phraseFields"] = '{"taobaoReview":1}';
            _commentTask["taskPlatfromType"] = "taobaoReview";
            commentExec(comment_tmInfo, next);
            break;

        case "jd":
            _commentTask["phraseFields"] = '{"jingdongReview":1}';
            _commentTask["taskPlatfromType"] = "jingdongReview";
            commentExec(comment_jdShopInfo);
            break;

        case "jds":
            _commentTask["phraseFields"] = '{"jingdongReview":1}';
            _commentTask["taskPlatfromType"] = "jingdongReview";
            commentExec(comment_jdShopInfo2);
            break;
    }
}
//--------------------------平台判断
function distPlat(url) {
    console.log(url);
    var _plat = url.split("/")[2].split(".");
    if (_plat.indexOf("www") > 0) {
        return "err";
    }
    if (_plat.indexOf("taobao") > 0 || _plat.indexOf("jiyoujia") > 0) {
        return "taobao";
    } else if (_plat.indexOf("tmall") > 0) {
        return "tmall";
    } else if (_plat.indexOf("jd") > 0) {
        return "jd";
    } else {
        if (url.indexOf("jd") > 0) {
            return "jds"
        } else {
            console.log(_plat);
            return "other";
        }
    }
}
// ---------------评论任务数据抓取
function commentExec(platJS, next) {
    // if (!next) {
    //     next = 2;
    //     console.log("casperjs 首次进入");
    // }
    var _dos = exec("casperjs " + platJS + " --surl=" + _datataskUrl);
    // var _dos = exec("casperjs " + platJS + " --surl=" + _datataskUrl + " --PTN=" + next);
    var Pt = platJS;
    var PNT = nextPage;
    _dos.stdout.on('data', function (data) {
        console.log(data);
    });
    _dos.stderr.on('data', function (data) {
        console.log('报错啦~~：\n' + data);
    });

    _dos.on('exit', function (code, plat, type) {
        if (code == 2) {
            console.log("********" + code);
            //            console.log("********"+PNT);
            //console.log("子进程受限退出，代码：" + code + "... 重新拨号 ...");
            setTimeout(function () {
                redialNet(offnet);
            }, 500);
            setTimeout(function () {
                redialNet(onnet);
            }, 2000);
            setTimeout(function () {
                redialNet(connect);
            }, 3000);
            setTimeout(function () {
                clearInterval(getTaskTimer12);
                getTaskTimer12 = iTimer12(true);
                // commentExec(Pt,PNT);
            }, 10000);
        }
    });
}
function setSpInfo(shopInfo, tName) {
    taskList[tName]["shopInfo"] = JSON.parse(shopInfo);
    console.log("((((((((((" + JSON.stringify(shopInfo) + "))))))))))))");
    console.log(taskList[tName]["shopInfo"]["wangWang"]);
    taskList[tName]["shopInfo"]["salesVol"] = 0;
    taskList[tName]["shopInfo"]["state"] = "1";
    taskList[tName]["shopInfo"]["create_taskId"] = taskList[tName]["create_taskId"];
    taskList[tName]["shopInfo"]["object_Id"] = taskList[tName]["object_Id"];
    taskList[tName]["shopInfo"]["taskStateRecord"] = taskList[tName]["taskStateRecord"];
}
function countSales(sales, tName) {

    if (sales !== sales || sales === undefined || sales === "" || sales === "NaN") {
        sales = 0;
    }
    taskList[tName]["shopInfo"]["salesVol"] = sales;
}

function expExcel(data, tName, type, page) {
    var _taskItem = taskList[tName];
    taskList[tName]["rootNum"] = page;
    var datares = JSON.parse(data);
    var rootArr = [], childArr = [];

    //if(_taskItem["rootNum"] == 1 && type !== undefined){
    rootArr = [csvNames[type]];
    //}

    for (dataroot in datares) {
        for (datachild in datares[dataroot]) {
            childArr.push(datares[dataroot][datachild]);
        }
        rootArr.push(childArr);
        childArr = [];
    }

    // var _shopItems = [];
    var _items = {};
    if (rootArr.length > 2) {
        rootArr.forEach(function (res, i) {
            if (i > 0) {
                res.forEach(function (item, m) {
                    _items[rootArr[0][m]] = item;
                });
                taskShopItem.push(_items);
                _items = {};
            }
        });
    }
    // taskShopItem = _shopItems;
};

function setVal_jd(tName, _inum) {
    taskList[tName]["rootNum"] = _inum;
}
function SetUrl(sUrl, tName) {
    taskList[tName]["rootUrl"] = '"' + sUrl + '"';
}

function arrDel(arr, str) {
    arr.forEach(function (res, i) {
        if (res === str) {
            arr.splice(i, 1);
        }
    });
    return arr;
}

function jsonDel(json, name) {
    var _json = {};

    for (jsonName in json) {
        if (jsonName !== name) {
            _json[jsonName] = json[jsonName];
        }
    }
    return _json;
}
var Infos = [];
function setTmShopInf(json, numb) {
    var data = JSON.parse(json);
    _commentTask["note"] = {};
    _commentTask["note"]["url"] = data["url"];
    _commentTask["note"]["goodName"] = data["goodName"];
    _commentTask["note"]["picUrl"] = data["picUrl"];
    _commentTask["note"]["keyWordId"] = _dataobjectId;
    _commentTask["note"] = JSON.stringify(_commentTask["note"]);
    console.log("keyWordId------" + _dataobjectId);
    _commentTask["pTrid"] = data["pTrid"];
    _commentTask["taskUrl"] = data["url"];
    _commentTask["phraseFields"] = '{"taobaoReview":1}';
    _commentTask["taskPlatfromType"] = "taobaoReview";
    sendTask(_commentTask);
    getData1(_commentTask);
}
function setJdShopInfo(json) {
    var data = JSON.parse(json);
    _commentTask["note"] = {};
    _commentTask["note"]["url"] = data["url"];
    _commentTask["note"]["goodName"] = data["goodName"];
    _commentTask["note"]["picUrl"] = data["picUrl"];
    _commentTask["note"]["keyWordId"] = _dataobjectId;
    _commentTask["note"] = JSON.stringify(_commentTask["note"]);
    console.log("keyWordId------" + _dataobjectId);
    _commentTask["pTrid"] = data["pTrid"];
    _commentTask["taskUrl"] = data["url"];
    _commentTask["taskPlatfromType"] = "jingdongReview";
    _commentTask["phraseFields"] = '{"jingdongReview":1}';
    sendTask(_commentTask);
    getData1(_commentTask);
}
function iTimer12(me) {
    return setInterval(function () {
        console.log("等待任务ing..." + me);
        getCom_Task(_dts, me);
        me = false;
    }, 20000);
}

function redialNet(mlh) {
    var netObj = exec(mlh);
    netObj.stdout.on('data', function (data) {
        console.log(data);
    });

    // 捕获标准错误输出并将其打印到控制台
    netObj.stderr.on('data', function (data) {
        console.log('报错啦~~：\n' + data);
    });
    // 注册子进程关闭事件
    netObj.on('exit', function (code, signal) {
        console.log("正在重启网络..." + code);
    });
}
function boolInfo(Id, type) {
    if (type == 12) {
        var fileDataSu12 = fs.readFileSync("test/succeed12.text", { encoding: "utf-8" }, function (err, data) {
            var dataSu12 = JSON.parse(data);
            return dataSu12;
        });
        console.log("-----------------+++" + Id);
        var lengthSu12 = fileDataSu12.split("\n").length;
        for (var i = 0; i < lengthSu12 - 1; i++) {
            if (fileDataSu12.split("\n")[i].split(",")[1].split(":")[1] == Id) {
                return true;
            }
        }
    } else {
        var fileDataSu = fs.readFileSync("test/succeed.text", { encoding: "utf-8" }, function (err, data) {
            var dataSu = JSON.parse(data);
            return dataSu;
        });
        console.log("-----------------+++" + Id);
        var lengthSu = fileDataSu.split("\n").length;
        for (var i = 0; i < lengthSu - 1; i++) {
        }
    }

}
function taskNumber(_jId) {
    var count = 0;
    var fileDataMes = fs.readFileSync("test/mes.text", { encoding: "utf-8" }, function (err, data) {
        var dataMes = data.JSON.parse(data);
        return dataMes;
    });
    var lengthMes = fileDataMes.split("\n").length;
    for (var i = 0; i < lengthMes; i++) {
        if (_jId == fileDataMes.split("\n")[i].split(",")[1].split(":")[1]) {
            count++;
            if (count > 10) {
                return true;
            }
        }
    }
}

function record(res) {
    console.log(res);
    var data = "记录发送时间:" + new Date() + ", " + "任务ID:" + res["pTrid"] + ", " + "node" + res["note"] + "\n";
    try {
        fs.readFileSync('test/commentInfo' + '.text', { encoding: 'utf-8' });
    } catch (e) {
        //fs.mkdirSync('./test', 0777);
    }
    fs.writeFileSync('test/commentInfo' + '.text', data, { flag: 'a' });
}
function getData1(data) {
    try {
        if (data) {
            var notesFile12 = "任务开始时间:" + new Date() + ", " + "任务ID:" + data["objectId"] + "," + "keywordid------" + JSON.parse(data.note).keyWordId + "," + "宝贝id" + data["pTrid"] + "," + "宝贝URL：" + JSON.parse(data.note).url + "\n";
            try {
                fs.readFileSync('test/filesuccesss' + '.test', { encoding: 'utf-8' });
            } catch (e) {
                //fs.mkdirSync('./test', 0777);
            }
            fs.writeFileSync('test/filesuccesss' + '.test', notesFile12, { flag: 'a' });
        }
    } catch (e) {
        console.log("放弃一个错误.")
    }
}
